# -*- coding: utf-8 -*-
# قارئ القرآن - mizouh المتميز (Enigma2 Plugin)
# Compatible with Python 3 (OpenATV 7.x, OpenPLi 9.x, OpenBH, Egami, VTi, DreamOS)

from .version import PLUGIN_VERSION, GITHUB_RAW_BASE

__version__ = PLUGIN_VERSION
__author__ = "mizouh"
__plugin_name__ = "قارئ القرآن - mizouh المتميز"
