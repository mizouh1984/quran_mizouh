# -*- coding: utf-8 -*-
"""
GitHub OTA Auto-Updater for قارئ القرآن - mizouh المتميز
Checks version.json & reciters_feed.json hosted on the owner's GitHub repository,
guards flash free space (>= 5 MB), enforces strict 755 dir / 644 file permissions,
and pushes automatic mass updates to all customer Enigma2 receivers at once.
"""

import json
import os
import ssl
import tarfile
import time
import urllib.request

from .version import (
    PLUGIN_VERSION,
    VERSION_MANIFEST_URL,
    RECITERS_FEED_URL,
    PACKAGE_TAR_URL,
)

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_FILE = os.path.join(PLUGIN_DIR, "reciters_feed.json")
MIN_FLASH_FREE_BYTES = 5 * 1024 * 1024  # 5 MB Flash Space Guard


def _parse_version(ver_str):
    parts = []
    for token in str(ver_str or "0").strip().lstrip("vV").split("."):
        try:
            parts.append(int(token))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def _ssl_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _has_enough_flash_space(path="/", min_bytes=MIN_FLASH_FREE_BYTES):
    try:
        st = os.statvfs(path)
        free_bytes = st.f_bavail * st.f_frsize
        return free_bytes >= min_bytes, free_bytes
    except Exception:
        return True, min_bytes


def _apply_safe_permissions(target_dir):
    """Applies strict 755 for directories and 644 for files (never blanket chmod -R 755)."""
    try:
        os.chmod(target_dir, 0o755)
    except OSError:
        pass
    for root, dirs, files in os.walk(target_dir):
        try:
            os.chmod(root, 0o755)
        except OSError:
            pass
        for d_name in dirs:
            try:
                os.chmod(os.path.join(root, d_name), 0o755)
            except OSError:
                pass
        for f_name in files:
            try:
                os.chmod(os.path.join(root, f_name), 0o644)
            except OSError:
                pass


class PluginAutoUpdater:
    """Checks GitHub for plugin OTA updates and periodic reciter feed updates."""

    def _fetch_bytes(self, url, timeout=10):
        sep = "&" if "?" in url else "?"
        bust_url = f"{url}{sep}t={int(time.time())}"
        req = urllib.request.Request(
            bust_url,
            headers={"User-Agent": f"QuranMizouh-Updater/{PLUGIN_VERSION}"},
        )
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context()) as resp:
            return resp.read()

    def check_for_update(self):
        """Returns remote manifest dict if remote GitHub version > local PLUGIN_VERSION, else None."""
        try:
            raw = self._fetch_bytes(VERSION_MANIFEST_URL, timeout=8)
            manifest = json.loads(raw.decode("utf-8"))
            remote_ver = str(manifest.get("version", "")).strip()
            if remote_ver and _parse_version(remote_ver) > _parse_version(PLUGIN_VERSION):
                return manifest
        except Exception:
            pass
        return None

    def sync_reciters_feed(self):
        """Silently downloads updated reciters_feed.json from GitHub if valid."""
        try:
            raw = self._fetch_bytes(RECITERS_FEED_URL, timeout=8)
            data = json.loads(raw.decode("utf-8"))
            reciters = data.get("reciters", [])
            if isinstance(reciters, list) and len(reciters) >= 5:
                tmp_path = CATALOG_FILE + ".part"
                with open(tmp_path, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                os.replace(tmp_path, CATALOG_FILE)
                try:
                    os.chmod(CATALOG_FILE, 0o644)
                except OSError:
                    pass
                return True
        except Exception:
            pass
        return False

    def download_and_install_update(self, manifest):
        """
        Verifies >= 5 MB free flash space on /, downloads tar.gz from GitHub into .part,
        extracts cleanly into QuranMizouh, and applies 755/644 permissions.
        """
        enough_space, free_bytes = _has_enough_flash_space("/")
        if not enough_space:
            free_mb = round(free_bytes / (1024.0 * 1024.0), 2)
            return False, f"المساحة الحرة على الفلاش ({free_mb} MB) أقل من 5 MB — تم إلغاء التحديث حمايةً للرسيفر."

        pkg_url = manifest.get("package_url") or PACKAGE_TAR_URL
        tmp_part = "/tmp/quran_mizouh_ota.tar.gz.part"
        tmp_tar = "/tmp/quran_mizouh_ota.tar.gz"
        try:
            data = self._fetch_bytes(pkg_url, timeout=25)
            if not data or len(data) < 2048:
                return False, "ملف التحديث المستلم من GitHub غير مكتمل."

            with open(tmp_part, "wb") as f:
                f.write(data)
            os.replace(tmp_part, tmp_tar)

            with tarfile.open(tmp_tar, "r:gz") as tar:
                members = [
                    m for m in tar.getmembers()
                    if m.name.startswith("usr/lib/enigma2/python/Plugins/Extensions/QuranMizouh/")
                    and ".." not in m.name
                ]
                tar.extractall(path="/", members=members)

            _apply_safe_permissions(PLUGIN_DIR)
            return True, "تم تثبيت التحديث الجديد بنجاح من GitHub!"
        except Exception as err:
            return False, f"فشل تحميل التحديث من GitHub: {err}"
        finally:
            for p in (tmp_part, tmp_tar):
                try:
                    if os.path.exists(p):
                        os.remove(p)
                except OSError:
                    pass
