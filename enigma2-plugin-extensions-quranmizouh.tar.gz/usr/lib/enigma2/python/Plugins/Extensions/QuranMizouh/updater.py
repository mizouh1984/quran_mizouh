# -*- coding: utf-8 -*-
"""
GitHub OTA Auto-Updater for قارئ القرآن - mizouh المتميز
Checks version.json & reciters_feed.json hosted on the owner's GitHub repository
and pushes automatic mass updates to all customer Enigma2 receivers at once.
"""

import json
import os
import ssl
import tarfile
import time
import urllib.request

from .version import (
    PLUGIN_VERSION,
    VERSION_MANIFEST_URL,
    RECITERS_FEED_URL,
    PACKAGE_TAR_URL,
)

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_FILE = os.path.join(PLUGIN_DIR, "reciters_feed.json")


def _parse_version(ver_str):
    parts = []
    for token in str(ver_str or "0").strip().lstrip("vV").split("."):
        try:
            parts.append(int(token))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def _ssl_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


class PluginAutoUpdater:
    """Checks GitHub for plugin OTA updates and periodic reciter feed updates."""

    def _fetch_bytes(self, url, timeout=10):
        sep = "&" if "?" in url else "?"
        bust_url = f"{url}{sep}t={int(time.time())}"
        req = urllib.request.Request(
            bust_url,
            headers={"User-Agent": f"QuranMizouh-Updater/{PLUGIN_VERSION}"},
        )
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context()) as resp:
            return resp.read()

    def check_for_update(self):
        """Returns remote manifest dict if remote GitHub version > local PLUGIN_VERSION, else None."""
        try:
            raw = self._fetch_bytes(VERSION_MANIFEST_URL, timeout=8)
            manifest = json.loads(raw.decode("utf-8"))
            remote_ver = str(manifest.get("version", "")).strip()
            if remote_ver and _parse_version(remote_ver) > _parse_version(PLUGIN_VERSION):
                return manifest
        except Exception:
            pass
        return None

    def sync_reciters_feed(self):
        """Silently downloads updated reciters_feed.json from GitHub if valid."""
        try:
            raw = self._fetch_bytes(RECITERS_FEED_URL, timeout=8)
            data = json.loads(raw.decode("utf-8"))
            reciters = data.get("reciters", [])
            if isinstance(reciters, list) and len(reciters) >= 5:
                tmp_path = CATALOG_FILE + ".tmp"
                with open(tmp_path, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                os.replace(tmp_path, CATALOG_FILE)
                return True
        except Exception:
            pass
        return False

    def download_and_install_update(self, manifest):
        """Downloads tar.gz package from GitHub and extracts cleanly over /usr/lib/enigma2/python/Plugins/Extensions/QuranMizouh."""
        pkg_url = manifest.get("package_url") or PACKAGE_TAR_URL
        tmp_tar = "/tmp/quran_mizouh_ota.tar.gz"
        try:
            data = self._fetch_bytes(pkg_url, timeout=25)
            with open(tmp_tar, "wb") as f:
                f.write(data)

            with tarfile.open(tmp_tar, "r:gz") as tar:
                members = [
                    m for m in tar.getmembers()
                    if m.name.startswith("usr/lib/enigma2/python/Plugins/Extensions/QuranMizouh/")
                ]
                tar.extractall(path="/", members=members)

            os.system(f"chmod -R 755 {PLUGIN_DIR}")
            try:
                os.remove(tmp_tar)
            except OSError:
                pass
            return True, "تم تثبيت التحديث الجديد بنجاح من GitHub!"
        except Exception as err:
            return False, f"فشل تحميل التحديث من GitHub: {err}"
