# -*- coding: utf-8 -*-
# الإصدار الرسمي وإعدادات مستودع التحديث التلقائي عبر GitHub

PLUGIN_VERSION = "3.3.0"
GITHUB_USER = "mizouh1984"
GITHUB_REPO = "quran_mizouh"
GITHUB_BRANCH = "main"
GITHUB_RAW_BASE = "https://raw.githubusercontent.com/mizouh1984/quran_mizouh/main"
VERSION_MANIFEST_URL = f"{GITHUB_RAW_BASE}/version.json"
RECITERS_FEED_URL = f"{GITHUB_RAW_BASE}/reciters_feed.json"
PACKAGE_TAR_URL = f"{GITHUB_RAW_BASE}/enigma2-plugin-extensions-quranmizouh.tar.gz"
INSTALLER_SH_URL = f"{GITHUB_RAW_BASE}/install_quran_mizouh_allinone.sh"
