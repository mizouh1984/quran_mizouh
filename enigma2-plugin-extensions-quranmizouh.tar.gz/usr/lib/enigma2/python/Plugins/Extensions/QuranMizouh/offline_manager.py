# -*- coding: utf-8 -*-
import json
import os
import threading
import urllib.request

from .version import PLUGIN_VERSION


class OfflineManager:
    """
    Manages local HDD/USB storage for offline Quran audio, deduplicated Mushaf page images, and Tafsir JSON.
    Uses atomic .part temporary files + size validation + os.replace() to prevent corrupted/truncated files.
    """

    def __init__(self, base_dir="/media/hdd/QuranMizouh"):
        self.base_dir = base_dir
        self.audio_dir = os.path.join(base_dir, "audio")
        self.text_dir = os.path.join(base_dir, "text")
        self.pages_dir = os.path.join(base_dir, "mushaf_pages")
        self._page_lock = threading.Lock()
        self._inflight_pages = set()
        self._ensure_dirs()

    def _ensure_dirs(self):
        for path in (self.base_dir, self.audio_dir, self.text_dir, self.pages_dir):
            try:
                os.makedirs(path, exist_ok=True)
            except OSError:
                pass

    def _cleanup_part(self, part_path):
        try:
            if part_path and os.path.exists(part_path):
                os.remove(part_path)
        except OSError:
            pass

    def get_cached_mushaf_page(self, page_number):
        target = os.path.join(self.pages_dir, f"page_{page_number:03d}.jpg")
        if os.path.exists(target) and os.path.getsize(target) > 2048:
            return target
        return None

    def get_or_download_mushaf_page(self, page_number):
        self._ensure_dirs()
        cached = self.get_cached_mushaf_page(page_number)
        if cached:
            return cached

        with self._page_lock:
            if page_number in self._inflight_pages:
                return None
            self._inflight_pages.add(page_number)

        target = os.path.join(self.pages_dir, f"page_{page_number:03d}.jpg")
        tmp = f"{target}.part"
        mirrors = [
            f"https://www.mp3quran.net/api/quran_pages_arabic/{page_number:03d}.jpg",
            f"https://quran.ksu.edu.sa/png_big/{page_number}.png",
        ]
        try:
            for url in mirrors:
                try:
                    req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
                    with urllib.request.urlopen(req, timeout=7) as resp, open(tmp, "wb") as out:
                        out.write(resp.read())
                    if os.path.exists(tmp) and os.path.getsize(tmp) > 2048:
                        os.replace(tmp, target)
                        return target
                    self._cleanup_part(tmp)
                except Exception:
                    self._cleanup_part(tmp)
                    continue
            return None
        finally:
            with self._page_lock:
                self._inflight_pages.discard(page_number)

    def get_local_mp3(self, reciter_id, surah_number):
        return os.path.join(self.audio_dir, f"{reciter_id}_{surah_number:03d}.mp3")

    def download_surah(self, reciter_id, surah_number, url):
        """Safely downloads audio MP3 into a .part file, validates size, and atomically replaces target."""
        self._ensure_dirs()
        target = self.get_local_mp3(reciter_id, surah_number)
        tmp = f"{target}.part"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
            with urllib.request.urlopen(req, timeout=45) as resp:
                expected_len = int(resp.headers.get("Content-Length") or 0)
                downloaded = 0
                with open(tmp, "wb") as out:
                    while True:
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        out.write(chunk)
                        downloaded += len(chunk)

            # Verify downloaded file is valid and complete before promoting
            actual_size = os.path.getsize(tmp) if os.path.exists(tmp) else 0
            if actual_size < 8192:
                self._cleanup_part(tmp)
                return None
            if expected_len > 0 and actual_size < int(expected_len * 0.98):
                self._cleanup_part(tmp)
                return None

            os.replace(tmp, target)
            return target
        except Exception:
            self._cleanup_part(tmp)
            return None

    def save_surah_json(self, surah_number, tafsir_edition, ayahs, tafsirs):
        self._ensure_dirs()
        path = os.path.join(self.text_dir, f"surah_{surah_number:03d}_{tafsir_edition}.json")
        tmp = f"{path}.part"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"ayahs": ayahs, "tafsirs": tafsirs}, f, ensure_ascii=False)
            os.replace(tmp, path)
        except OSError:
            self._cleanup_part(tmp)

    def load_surah_json(self, surah_number, tafsir_edition):
        path = os.path.join(self.text_dir, f"surah_{surah_number:03d}_{tafsir_edition}.json")
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return None
        return None
