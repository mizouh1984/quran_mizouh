# -*- coding: utf-8 -*-
import json
import os
import urllib.request

from .version import PLUGIN_VERSION


class OfflineManager:
    """Manages local HDD/USB storage for offline Quran audio, real Mushaf page images, and Tafsir JSON."""

    def __init__(self, base_dir="/media/hdd/QuranMizouh"):
        self.base_dir = base_dir
        self.audio_dir = os.path.join(base_dir, "audio")
        self.text_dir = os.path.join(base_dir, "text")
        self.pages_dir = os.path.join(base_dir, "mushaf_pages")
        self._ensure_dirs()

    def _ensure_dirs(self):
        for path in (self.base_dir, self.audio_dir, self.text_dir, self.pages_dir):
            try:
                os.makedirs(path, exist_ok=True)
            except OSError:
                pass

    def get_or_download_mushaf_page(self, page_number):
        self._ensure_dirs()
        target = os.path.join(self.pages_dir, f"page_{page_number:03d}.jpg")
        if os.path.exists(target) and os.path.getsize(target) > 2048:
            return target
        mirrors = [
            f"https://www.mp3quran.net/api/quran_pages_arabic/{page_number:03d}.jpg",
            f"https://quran.ksu.edu.sa/png_big/{page_number}.png",
        ]
        for url in mirrors:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
                with urllib.request.urlopen(req, timeout=12) as resp, open(target, "wb") as out:
                    out.write(resp.read())
                return target
            except Exception:
                continue
        return None

    def get_local_mp3(self, reciter_id, surah_number):
        return os.path.join(self.audio_dir, f"{reciter_id}_{surah_number:03d}.mp3")

    def download_surah(self, reciter_id, surah_number, url):
        self._ensure_dirs()
        target = self.get_local_mp3(reciter_id, surah_number)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
            with urllib.request.urlopen(req, timeout=30) as resp, open(target, "wb") as out:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    out.write(chunk)
            return target
        except Exception:
            return None

    def save_surah_json(self, surah_number, tafsir_edition, ayahs, tafsirs):
        self._ensure_dirs()
        path = os.path.join(self.text_dir, f"surah_{surah_number:03d}_{tafsir_edition}.json")
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"ayahs": ayahs, "tafsirs": tafsirs}, f, ensure_ascii=False)
        except OSError:
            pass

    def load_surah_json(self, surah_number, tafsir_edition):
        path = os.path.join(self.text_dir, f"surah_{surah_number:03d}_{tafsir_edition}.json")
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return None
        return None
