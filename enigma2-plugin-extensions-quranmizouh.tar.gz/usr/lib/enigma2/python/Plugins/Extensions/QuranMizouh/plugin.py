# -*- coding: utf-8 -*-
"""
قارئ القرآن - mizouh المتميز (Quran Reader - mizouh Al-Mutamayiz)
Enigma2 FullHD (1920x1080) Plugin v3.0.0
Features:
  - Continuous Zero-Delay Full-Surah Recitation (31+ Hafs & Warsh Reciters incl. Ahmad Al-Ajmy)
  - Clean Unobstructed Real Printed Madinah Mushaf Pages (Auto Page Turn, NO Overlay Box/Bar)
  - Companion Tafsir + Advanced Search + Audio-Only Mode + Offline HDD/USB Cache
  - Built-in GitHub OTA Auto-Updater (updates all receivers automatically when new version is pushed)
"""

import os
import re
import threading
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from Components.ScrollLabel import ScrollLabel
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigInteger, ConfigYesNo, getConfigListEntry
from enigma import eServiceReference, ePicLoad, eTimer, iPlayableService
from Components.ServiceEventTracker import ServiceEventTracker

from .version import PLUGIN_VERSION
from .quran_api import QuranAPI, SURAHS_LIST
from .offline_manager import OfflineManager
from .updater import PluginAutoUpdater
from .locale_loader import LocaleLoader

# Persistent Enigma2 Plugin Configuration
config.plugins.quranmizouh = ConfigSubsection()
config.plugins.quranmizouh.language = ConfigSelection(default="ar", choices=[("ar", "العربية"), ("en", "English"), ("fr", "Français")])
config.plugins.quranmizouh.riwaya = ConfigSelection(default="hafs", choices=[("hafs", "حفص عن عاصم"), ("warsh", "ورش عن نافع")])
config.plugins.quranmizouh.show_mushaf = ConfigYesNo(default=True)
config.plugins.quranmizouh.mushaf_mode = ConfigSelection(default="image", choices=[("image", "صورة المصحف الحقيقية"), ("text", "المصحف النصي")])
config.plugins.quranmizouh.auto_update = ConfigYesNo(default=True)
config.plugins.quranmizouh.tafsir_edition = ConfigSelection(
    default="ar.muyassar",
    choices=[
        ("ar.muyassar", "التفسير الميسر"),
        ("ar.jalalayn", "تفسير الجلالين"),
        ("ar.baghawi", "تفسير البغوي"),
        ("en.sahih", "Sahih International (EN)"),
        ("fr.hamidullah", "Hamidullah (FR)"),
    ],
)
config.plugins.quranmizouh.font_size = ConfigInteger(default=32, limits=(22, 46))
config.plugins.quranmizouh.storage_path = ConfigSelection(
    default="/media/hdd/QuranMizouh",
    choices=[
        ("/media/hdd/QuranMizouh", "/media/hdd/QuranMizouh"),
        ("/media/usb/QuranMizouh", "/media/usb/QuranMizouh"),
        ("/tmp/QuranMizouh", "/tmp/QuranMizouh"),
    ],
)

MUSHAF_W = 576
MUSHAF_H = 824

DIACRITICS_RE = re.compile(r"[\u064B-\u065F\u0670\u06D6-\u06ED\s]+")


def strip_diacritics(text):
    return DIACRITICS_RE.sub("", text or "")


class QuranMizouhMainScreen(Screen):
    skin = """
    <screen name="QuranMizouhMainScreen" position="0,0" size="1920,1080" title="قارئ القرآن - mizouh المتميز" flags="wfNoBorder" backgroundColor="#090E0D">
        <!-- Header Bar with Clear Version Number -->
        <eLabel position="0,0" size="1920,88" backgroundColor="#101917" zPosition="-1" />
        <eLabel position="0,88" size="1920,2" backgroundColor="#C9A24D" zPosition="0" />
        <widget name="header_title" position="64,20" size="860,48" font="Regular;34" foregroundColor="#E5C878" backgroundColor="#101917" halign="right" transparent="1" />
        <widget name="riwaya_label" position="940,24" size="916,42" font="Regular;25" foregroundColor="#A8BDB6" backgroundColor="#101917" halign="left" transparent="1" />

        <!-- Right Sidebar: 31+ Reciters & All 114 Surahs -->
        <eLabel position="1352,106" size="504,840" backgroundColor="#111A18" zPosition="-1" />
        <widget name="reciter_title" position="1372,118" size="464,36" font="Regular;24" foregroundColor="#D4AF37" backgroundColor="#111A18" halign="right" transparent="1" />
        <widget name="reciter_list" position="1372,160" size="464,260" itemHeight="40" font="Regular;22" foregroundColor="#EAECEB" backgroundColor="#111A18" scrollbarMode="showOnDemand" />
        <eLabel position="1372,430" size="464,1" backgroundColor="#243531" />
        <widget name="surah_title" position="1372,442" size="464,36" font="Regular;24" foregroundColor="#D4AF37" backgroundColor="#111A18" halign="right" transparent="1" />
        <widget name="surah_list" position="1372,484" size="464,448" itemHeight="40" font="Regular;22" foregroundColor="#EAECEB" backgroundColor="#111A18" scrollbarMode="showOnDemand" />

        <!-- Center Pure Real Printed Mushaf Page (576x824, ZERO overlay bars or boxes) -->
        <eLabel position="708,106" size="600,840" backgroundColor="#F5EFE1" zPosition="-1" />
        <widget name="mushaf_page" position="720,114" size="576,824" alphatest="blend" zPosition="1" />

        <!-- Interactive Text Mushaf Fallback -->
        <widget name="mushaf_text" position="714,122" size="588,808" font="Regular;30" foregroundColor="#F5F3EE" backgroundColor="#0D1412" halign="right" zPosition="4" />

        <!-- Audio-Only Sanctuary View -->
        <widget name="audio_only_status" position="80,260" size="1220,300" font="Regular;38" foregroundColor="#E5C878" backgroundColor="#0D1412" halign="center" valign="center" transparent="1" zPosition="5" />

        <!-- Left Pane: Surah Header + Ayah Text + Companion Tafsir -->
        <eLabel position="64,106" size="618,840" backgroundColor="#0D1513" zPosition="-1" />
        <widget name="surah_banner" position="84,124" size="578,48" font="Regular;28" foregroundColor="#F2DFAA" backgroundColor="#0D1513" halign="center" transparent="1" />
        <widget name="active_ayah_label" position="84,186" size="578,225" font="Regular;26" foregroundColor="#FFF3C8" backgroundColor="#121D1A" halign="right" valign="center" />
        <eLabel position="84,424" size="578,2" backgroundColor="#C9A24D" />
        <widget name="tafsir_text" position="84,440" size="578,490" font="Regular;23" foregroundColor="#C6D4CF" backgroundColor="#0D1513" halign="right" transparent="1" />

        <!-- Bottom Remote Control Color Key Bar -->
        <eLabel position="0,964" size="1920,116" backgroundColor="#101917" zPosition="-1" />
        <eLabel position="0,962" size="1920,2" backgroundColor="#243531" />

        <eLabel position="1828,996" size="22,22" backgroundColor="#DC2626" />
        <widget name="key_red" position="1548,988" size="268,38" font="Regular;22" foregroundColor="#EAECEB" halign="right" transparent="1" />

        <eLabel position="1508,996" size="22,22" backgroundColor="#16A34A" />
        <widget name="key_green" position="1208,988" size="288,38" font="Regular;22" foregroundColor="#EAECEB" halign="right" transparent="1" />

        <eLabel position="1168,996" size="22,22" backgroundColor="#EAB308" />
        <widget name="key_yellow" position="838,988" size="318,38" font="Regular;22" foregroundColor="#EAECEB" halign="right" transparent="1" />

        <eLabel position="798,996" size="22,22" backgroundColor="#2563EB" />
        <widget name="key_blue" position="518,988" size="268,38" font="Regular;22" foregroundColor="#EAECEB" halign="right" transparent="1" />

        <widget name="status_bar" position="64,988" size="430,38" font="Regular;21" foregroundColor="#D4AF37" halign="left" transparent="1" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.prev_service = self.session.nav.getCurrentlyPlayingServiceReference()
        self.api = QuranAPI()
        self.offline = OfflineManager(config.plugins.quranmizouh.storage_path.value)
        self.updater = PluginAutoUpdater()
        self.locale = LocaleLoader(config.plugins.quranmizouh.language.value)
        self.picload = ePicLoad()

        self.riwaya = config.plugins.quranmizouh.riwaya.value
        self.show_mushaf = config.plugins.quranmizouh.show_mushaf.value
        self.mushaf_mode = config.plugins.quranmizouh.mushaf_mode.value
        self.active_pane = "surahs"
        self.current_surah = 1
        self.current_ayah = 1
        self.current_page = 1
        self.ayahs_data = []
        self.tafsirs_data = []
        self.exact_timings = []
        self.ayah_weight_ranges = []
        self.is_playing = False
        self.pending_update_info = None
        self.reciters = self.api.get_reciters_by_riwaya(self.riwaya)
        self.current_reciter = self.reciters[0]

        self["header_title"] = Label(f"قارئ القرآن - mizouh المتميز   v{PLUGIN_VERSION}")
        self["riwaya_label"] = Label("")
        self["reciter_title"] = Label(self.locale.t("reciters"))
        self["surah_title"] = Label(self.locale.t("surahs"))
        self["reciter_list"] = MenuList([])
        self["surah_list"] = MenuList([])
        self["surah_banner"] = Label("")
        self["mushaf_page"] = Pixmap()
        self["mushaf_text"] = ScrollLabel("")
        self["active_ayah_label"] = Label("")
        self["audio_only_status"] = Label("")
        self["tafsir_text"] = ScrollLabel("")
        self["key_red"] = Label(self.locale.t("key_red"))
        self["key_green"] = Label(self.locale.t("key_green"))
        self["key_yellow"] = Label(self.locale.t("key_yellow"))
        self["key_blue"] = Label(self.locale.t("key_blue"))
        self["status_bar"] = Label(f"v{PLUGIN_VERSION} · جاهز")

        # Gentle 500ms timer solely for automatic page turning & Tafsir sync (no overlay box)
        self.sync_timer = eTimer()
        self.sync_timer.callback.append(self.sync_page_from_playback)

        # Main-thread trigger for GitHub OTA update result
        self.update_ui_timer = eTimer()
        self.update_ui_timer.callback.append(self._handle_update_check_result)

        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evEOF: self.on_surah_finished,
        })

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "ChannelSelectBaseActions", "EPGSelectActions"],
            {
                "cancel": self.exit_plugin,
                "ok": self.on_ok,
                "up": self.move_up,
                "down": self.move_down,
                "left": self.switch_pane_reciters,
                "right": self.switch_pane_surahs,
                "red": self.stop_recitation,
                "green": self.toggle_play_pause,
                "yellow": self.toggle_mushaf_display,
                "blue": self.toggle_riwaya,
                "menu": self.open_settings,
                "info": self.open_search,
                "nextBouquet": self.next_ayah_seek,
                "prevBouquet": self.prev_ayah_seek,
            },
            -1,
        )

        self.picload.PictureData.get().append(self.on_mushaf_decoded)
        self.onLayoutFinish.append(self.initialize_ui)

    def initialize_ui(self):
        self.picload.setPara((MUSHAF_W, MUSHAF_H, 1, 1, False, 1, "#FAF6EC"))
        self.populate_lists()
        self.load_surah_content(self.current_surah)
        self.update_display_mode()
        if config.plugins.quranmizouh.auto_update.value:
            self.start_background_update_check()

    def start_background_update_check(self):
        """Checks GitHub version.json & reciters_feed.json in background without blocking Enigma2 UI."""
        def _worker():
            feed_updated = self.updater.sync_reciters_feed()
            update_info = self.updater.check_for_update()
            self.pending_update_info = {
                "feed_updated": feed_updated,
                "update": update_info,
            }
            self.update_ui_timer.start(150, True)

        t = threading.Thread(target=_worker, daemon=True)
        t.start()

    def _handle_update_check_result(self):
        result = self.pending_update_info
        self.pending_update_info = None
        if not result:
            return
        if result.get("feed_updated"):
            self.api.reload_catalog()
            self.populate_lists()
        update_info = result.get("update")
        if not update_info:
            return

        new_ver = update_info.get("version", "")
        changelog = update_info.get("changelog_ar") or update_info.get("changelog_en") or ""
        force_auto = bool(update_info.get("force_auto_update", False))

        if force_auto and config.plugins.quranmizouh.auto_update.value:
            self["status_bar"].setText(f"جارٍ التحديث التلقائي إلى v{new_ver}...")
            self.apply_ota_update(update_info)
        else:
            msg = (
                f"يتوفر تحديث جديد لبلوجن قارئ القرآن - mizouh المتميز\n"
                f"الإصدار الحالي: v{PLUGIN_VERSION}  ←  الإصدار الجديد: v{new_ver}\n\n"
                f"{changelog}\n\n"
                f"هل تريد التحديث الآن وإعادة تشغيل الواجهة؟"
            )
            self.session.openWithCallback(
                lambda confirmed: self.apply_ota_update(update_info) if confirmed else None,
                MessageBox,
                msg,
                MessageBox.TYPE_YESNO,
            )

    def apply_ota_update(self, update_info):
        ok, message = self.updater.download_and_install_update(update_info)
        if ok:
            self.session.openWithCallback(
                lambda _res=None: self.session.open(TryQuitMainloop, 3),
                MessageBox,
                f"{message}\nجارٍ إعادة تشغيل Enigma2 لتفعيل الإصدار الجديد v{update_info.get('version', '')}...",
                MessageBox.TYPE_INFO,
                timeout=3,
            )
        else:
            self["status_bar"].setText("تعذر التحديث التلقائي")
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=5)

    def on_mushaf_decoded(self, picInfo=None):
        ptr = self.picload.getData()
        if ptr is not None:
            self["mushaf_page"].instance.setPixmap(ptr)

    def populate_lists(self):
        self.reciters = self.api.get_reciters_by_riwaya(self.riwaya)
        if not self.reciters:
            return
        if self.current_reciter not in self.reciters:
            self.current_reciter = self.reciters[0]
        self["reciter_list"].setList([(r["name_ar"], r) for r in self.reciters])
        self["surah_list"].setList([(f"{s['number']:03d} - سورة {s['name_ar']}", s) for s in SURAHS_LIST])
        riwaya_title = "رواية حفص عن عاصم" if self.riwaya == "hafs" else "رواية ورش عن نافع"
        self["riwaya_label"].setText(f"{riwaya_title}  ·  {self.current_reciter['name_ar']}")

    def update_display_mode(self):
        if not self.show_mushaf:
            self["mushaf_page"].hide()
            self["mushaf_text"].hide()
            self["active_ayah_label"].hide()
            self["tafsir_text"].hide()
            self["audio_only_status"].show()
            surah_meta = SURAHS_LIST[self.current_surah - 1]
            self["audio_only_status"].setText(
                f"وضع الاستماع الصوتي (بدون إظهار المصحف)\n\nسورة {surah_meta['name_ar']}\nالقارئ: {self.current_reciter['name_ar']}"
            )
            return

        self["audio_only_status"].hide()
        self["active_ayah_label"].show()
        self["tafsir_text"].show()

        if self.mushaf_mode == "image":
            self["mushaf_text"].hide()
            self["mushaf_page"].show()
            self.render_mushaf_page_image(self.current_page)
        else:
            self["mushaf_page"].hide()
            self["mushaf_text"].show()

    def render_mushaf_page_image(self, page_num):
        img_path = self.offline.get_or_download_mushaf_page(page_num)
        if img_path and os.path.exists(img_path):
            self.picload.startDecode(img_path)

    def _compute_ayah_weight_ranges(self):
        self.ayah_weight_ranges = []
        if not self.ayahs_data:
            return
        intro = 32.0 if (self.current_surah != 1 and self.current_surah != 9) else 0.0
        weights = [max(10.0, len(strip_diacritics(a.get("text", ""))) + 6.0) for a in self.ayahs_data]
        total = intro + sum(weights)
        if total <= 0:
            return
        acc = intro
        for a, w in zip(self.ayahs_data, weights):
            s_r = acc / total
            acc += w
            e_r = acc / total
            self.ayah_weight_ranges.append((a["num"], s_r, e_r))

    def load_surah_content(self, surah_number):
        surah_meta = SURAHS_LIST[surah_number - 1]
        self["surah_banner"].setText(f"سورة {surah_meta['name_ar']}  ·  الآية {self.current_ayah}")
        self["status_bar"].setText("جارٍ تحميل المصحف والتفسير...")
        self.ayahs_data, self.tafsirs_data = self.api.fetch_surah_and_tafsir(
            surah_number,
            config.plugins.quranmizouh.tafsir_edition.value,
            self.offline,
        )
        self._compute_ayah_weight_ranges()
        mushaf_str = " ۝ ".join([f"{a['text']} ({a['num']})" for a in self.ayahs_data])
        self["mushaf_text"].setText(mushaf_str)
        self.update_active_ui(force_page_reload=True)
        self["status_bar"].setText(f"v{PLUGIN_VERSION} · صفحة {self.current_page}")

    def update_active_ui(self, force_page_reload=False):
        if not self.ayahs_data:
            return
        idx = max(0, min(len(self.ayahs_data) - 1, self.current_ayah - 1))
        ayah = self.ayahs_data[idx]
        tafsir = self.tafsirs_data[idx] if idx < len(self.tafsirs_data) else {"text": ""}
        new_page = ayah.get("page", 1)
        page_changed = force_page_reload or (new_page != self.current_page)
        self.current_page = new_page

        surah_meta = SURAHS_LIST[self.current_surah - 1]
        self["surah_banner"].setText(f"سورة {surah_meta['name_ar']}  ·  آية {ayah['num']}  ·  صفحة {self.current_page}")
        self["active_ayah_label"].setText(f"{ayah['text']} ۝{ayah['num']}")
        self["tafsir_text"].setText(f"التفسير:\n{tafsir['text']}")
        if self.show_mushaf and self.mushaf_mode == "image" and page_changed:
            self.render_mushaf_page_image(self.current_page)

    def play_continuous_surah(self):
        self.sync_timer.stop()
        self.exact_timings = []

        local_mp3 = self.offline.get_local_mp3(self.current_reciter["id"], self.current_surah)
        if local_mp3 and os.path.exists(local_mp3):
            url = local_mp3
            source_label = f"v{PLUGIN_VERSION} · تشغيل محلي"
        else:
            q_url, timings = self.api.fetch_continuous_surah_stream(self.current_reciter, self.current_surah)
            url = q_url or self.api.build_audio_url(self.current_reciter, self.current_surah)
            self.exact_timings = timings
            source_label = f"v{PLUGIN_VERSION} · تلاوة متصلة"

        sref = eServiceReference(4097, 0, url)
        sref.setName(f"سورة {SURAHS_LIST[self.current_surah - 1]['name_ar']} - {self.current_reciter['name_ar']}")
        self.session.nav.stopService()
        self.session.nav.playService(sref)
        self.is_playing = True
        self.current_ayah = 1
        self.update_active_ui()
        self["status_bar"].setText(source_label)
        self.sync_timer.start(500, False)

    def sync_page_from_playback(self):
        if not self.is_playing:
            return
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        if not seek:
            return
        pos_tuple = seek.getPlayPosition()
        if not pos_tuple or pos_tuple[0] != 0:
            return
        pos_sec = pos_tuple[1] / 90000.0

        matched_ayah = None
        if self.exact_timings:
            for item in self.exact_timings:
                if item["start"] <= pos_sec < item["end"]:
                    matched_ayah = item["ayah"]
                    break
        else:
            len_tuple = seek.getLength()
            if len_tuple and len_tuple[0] == 0 and len_tuple[1] > 0:
                total_sec = len_tuple[1] / 90000.0
                progress = pos_sec / total_sec
                for a_num, s_r, e_r in self.ayah_weight_ranges:
                    if s_r <= progress <= e_r:
                        matched_ayah = a_num
                        break

        if matched_ayah is not None and matched_ayah != self.current_ayah:
            self.current_ayah = matched_ayah
            self.update_active_ui()

    def _seek_to_ayah(self, target_ayah):
        self.current_ayah = target_ayah
        self.update_active_ui()
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        if not seek:
            return
        target_sec = None
        if self.exact_timings:
            for item in self.exact_timings:
                if item["ayah"] == target_ayah:
                    target_sec = item["start"]
                    break
        else:
            len_tuple = seek.getLength()
            if len_tuple and len_tuple[0] == 0 and len_tuple[1] > 0:
                total_sec = len_tuple[1] / 90000.0
                for a_num, s_r, _e_r in self.ayah_weight_ranges:
                    if a_num == target_ayah:
                        target_sec = s_r * total_sec
                        break
        if target_sec is not None:
            seek.seekTo(int(target_sec * 90000))

    def on_surah_finished(self):
        if not self.is_playing:
            return
        if self.current_surah < 114:
            self.current_surah += 1
            self.current_ayah = 1
            self.load_surah_content(self.current_surah)
            self.play_continuous_surah()

    def next_ayah_seek(self):
        if self.current_ayah < len(self.ayahs_data):
            self._seek_to_ayah(self.current_ayah + 1)

    def prev_ayah_seek(self):
        if self.current_ayah > 1:
            self._seek_to_ayah(self.current_ayah - 1)

    def toggle_play_pause(self):
        if not self.is_playing:
            self.play_continuous_surah()
            return
        service = self.session.nav.getCurrentService()
        pauseable = service and service.pause()
        if pauseable:
            pauseable.pause()
            self.is_playing = False
            self.sync_timer.stop()
            self["status_bar"].setText("إيقاف مؤقت")

    def stop_recitation(self):
        self.sync_timer.stop()
        self.session.nav.stopService()
        self.is_playing = False
        self["status_bar"].setText("تم الإيقاف")

    def toggle_mushaf_display(self):
        self.show_mushaf = not self.show_mushaf
        config.plugins.quranmizouh.show_mushaf.value = self.show_mushaf
        config.plugins.quranmizouh.show_mushaf.save()
        self.update_display_mode()

    def toggle_riwaya(self):
        self.riwaya = "warsh" if self.riwaya == "hafs" else "hafs"
        config.plugins.quranmizouh.riwaya.value = self.riwaya
        config.plugins.quranmizouh.riwaya.save()
        self.populate_lists()
        self.play_continuous_surah()

    def switch_pane_reciters(self):
        self.active_pane = "reciters"

    def switch_pane_surahs(self):
        self.active_pane = "surahs"

    def move_up(self):
        if self.active_pane == "reciters":
            self["reciter_list"].up()
        else:
            self["surah_list"].up()

    def move_down(self):
        if self.active_pane == "reciters":
            self["reciter_list"].down()
        else:
            self["surah_list"].down()

    def on_ok(self):
        if self.active_pane == "reciters":
            sel = self["reciter_list"].getCurrent()
            if sel:
                self.current_reciter = sel[1]
                riwaya_title = "رواية حفص عن عاصم" if self.riwaya == "hafs" else "رواية ورش عن نافع"
                self["riwaya_label"].setText(f"{riwaya_title}  ·  {self.current_reciter['name_ar']}")
                self.play_continuous_surah()
        else:
            sel = self["surah_list"].getCurrent()
            if sel:
                self.current_surah = sel[1]["number"]
                self.current_ayah = 1
                self.load_surah_content(self.current_surah)
                self.play_continuous_surah()

    def open_search(self):
        self.session.openWithCallback(self.execute_search, VirtualKeyBoard, title="البحث المتقدم في القرآن الكريم", text="")

    def execute_search(self, keyword):
        if not keyword:
            return
        results = self.api.search_verses(keyword)
        if not results:
            self.session.open(MessageBox, "لم يتم العثور على نتائج مطابقة.", MessageBox.TYPE_INFO, timeout=4)
            return
        first = results[0]
        self.current_surah = first["surah"]
        self.current_ayah = first["ayah"]
        self.load_surah_content(self.current_surah)
        self.play_continuous_surah()
        self._seek_to_ayah(first["ayah"])

    def open_settings(self):
        self.session.openWithCallback(self._on_settings_closed, QuranMizouhSettingsScreen, self.updater)

    def _on_settings_closed(self, trigger_update=False):
        if trigger_update:
            self.check_update_now()

    def check_update_now(self):
        self["status_bar"].setText("جارٍ فحص التحديثات من GitHub...")
        self.updater.sync_reciters_feed()
        self.api.reload_catalog()
        self.populate_lists()
        update_info = self.updater.check_for_update()
        if update_info:
            self.apply_ota_update(update_info)
        else:
            self["status_bar"].setText(f"v{PLUGIN_VERSION} · محدث")
            self.session.open(
                MessageBox,
                f"البلوجن محدث بالفعل إلى أحدث إصدار (v{PLUGIN_VERSION}) وتمت مزامنة قائمة القراء من GitHub.",
                MessageBox.TYPE_INFO,
                timeout=4,
            )

    def exit_plugin(self):
        self.sync_timer.stop()
        self.update_ui_timer.stop()
        self.session.nav.stopService()
        if self.prev_service:
            self.session.nav.playService(self.prev_service)
        self.close()


class QuranMizouhSettingsScreen(ConfigListScreen, Screen):
    skin = """
    <screen name="QuranMizouhSettingsScreen" position="center,center" size="1140,700" title="تخصيص قارئ القرآن - mizouh المتميز" backgroundColor="#0F1715">
        <widget name="version_banner" position="40,22" size="1060,40" font="Regular;25" foregroundColor="#E5C878" halign="center" transparent="1" />
        <widget name="config" position="40,74" size="1060,515" itemHeight="48" font="Regular;25" scrollbarMode="showOnDemand" />
        <widget name="hint" position="40,618" size="1060,48" font="Regular;22" foregroundColor="#D4AF37" halign="center" />
    </screen>
    """

    def __init__(self, session, updater=None):
        Screen.__init__(self, session)
        self.updater = updater
        entries = [
            getConfigListEntry("لغة الواجهة / Language", config.plugins.quranmizouh.language),
            getConfigListEntry("الرواية الافتراضية (حفص / ورش)", config.plugins.quranmizouh.riwaya),
            getConfigListEntry("إظهار المصحف الشريف أثناء التلاوة", config.plugins.quranmizouh.show_mushaf),
            getConfigListEntry("نمط المصحف (صورة حقيقية / نص)", config.plugins.quranmizouh.mushaf_mode),
            getConfigListEntry("التحديث التلقائي الدوري عبر GitHub", config.plugins.quranmizouh.auto_update),
            getConfigListEntry("مصدر التفسير / الترجمة", config.plugins.quranmizouh.tafsir_edition),
            getConfigListEntry("حجم الخط القرآني", config.plugins.quranmizouh.font_size),
            getConfigListEntry("مجلد التحميل بدون إنترنت", config.plugins.quranmizouh.storage_path),
        ]
        ConfigListScreen.__init__(self, entries)
        self["version_banner"] = Label(f"قارئ القرآن - mizouh المتميز  ·  الإصدار الرسمي v{PLUGIN_VERSION}")
        self["hint"] = Label("Green: حفظ الإعدادات   ·   Yellow: فحص تحديث GitHub الآن   ·   EXIT: إغلاق")
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "save": self.save_settings,
            "green": self.save_settings,
            "yellow": self.trigger_manual_update,
            "cancel": lambda: self.close(False),
        }, -1)

    def save_settings(self):
        for item in self["config"].list:
            item[1].save()
        self.close(False)

    def trigger_manual_update(self):
        self.close(True)


def main(session, **kwargs):
    session.open(QuranMizouhMainScreen)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=f"قارئ القرآن - mizouh المتميز v{PLUGIN_VERSION}",
            description=f"إصدار v{PLUGIN_VERSION} - تلاوة متصلة لـ 31+ قارئاً (حفص وورش) مع المصحف الحقيقي والتفسير والتحديث التلقائي عبر GitHub",
            where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
            fnc=main,
        )
    ]
