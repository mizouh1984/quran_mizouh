# -*- coding: utf-8 -*-
"""
قارئ القرآن - mizouh المتميز (Quran Reader - mizouh Al-Mutamayiz)
Enigma2 FullHD (1920x1080) Plugin v3.3.0
Performance & Feature Architecture:
  1. Zero-Lag Async Surah Switching: 0ms UI freeze — all HTTP & JSON I/O offloaded to background workers
  2. Instant Mushaf Page Display: Built-in 114-Surah page map + fast ePicLoad scaler + lazy text mode + dedup prefetch
  3. Persistent Auto-Resume (last_reciter, last_surah, last_ayah) saved on navigation & exit
  4. Background Offline Audio + Surah Text/Tafsir Download via REC / TEXT keys & top MENU action
  5. Full MENU Screen with 4 Live-Switchable FullHD Skins + GitHub OTA Auto-Updater + Official plugin.png Icon
"""

import os
import re
import time
import threading
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from Components.ScrollLabel import ScrollLabel
from Components.ConfigList import ConfigListScreen
from Components.config import (
    config,
    configfile,
    ConfigSubsection,
    ConfigSelection,
    ConfigInteger,
    ConfigText,
    ConfigYesNo,
    ConfigNothing,
    getConfigListEntry,
)
from enigma import eServiceReference, ePicLoad, eTimer, iPlayableService
from Components.ServiceEventTracker import ServiceEventTracker

from .version import PLUGIN_VERSION, GITHUB_USER, GITHUB_REPO
from .skins import SKIN_CHOICES, build_main_skin, build_menu_skin
from .quran_api import QuranAPI, SURAHS_LIST
from .offline_manager import OfflineManager
from .updater import PluginAutoUpdater
from .locale_loader import LocaleLoader

# Persistent Enigma2 Plugin Configuration (including Auto-Resume state)
config.plugins.quranmizouh = ConfigSubsection()
config.plugins.quranmizouh.skin_theme = ConfigSelection(default="emerald_gold", choices=SKIN_CHOICES)
config.plugins.quranmizouh.language = ConfigSelection(default="ar", choices=[("ar", "العربية"), ("en", "English"), ("fr", "Français")])
config.plugins.quranmizouh.riwaya = ConfigSelection(default="hafs", choices=[("hafs", "حفص عن عاصم"), ("warsh", "ورش عن نافع")])
config.plugins.quranmizouh.show_mushaf = ConfigYesNo(default=True)
config.plugins.quranmizouh.mushaf_mode = ConfigSelection(default="image", choices=[("image", "صورة المصحف الحقيقية"), ("text", "المصحف النصي")])
config.plugins.quranmizouh.auto_update = ConfigYesNo(default=True)
config.plugins.quranmizouh.last_reciter = ConfigText(default="", fixed_size=False)
config.plugins.quranmizouh.last_surah = ConfigInteger(default=1, limits=(1, 114))
config.plugins.quranmizouh.last_ayah = ConfigInteger(default=1, limits=(1, 286))
config.plugins.quranmizouh.tafsir_edition = ConfigSelection(
    default="ar.muyassar",
    choices=[
        ("ar.muyassar", "التفسير الميسر"),
        ("ar.jalalayn", "تفسير الجلالين"),
        ("ar.baghawi", "تفسير البغوي"),
        ("en.sahih", "Sahih International (EN)"),
        ("fr.hamidullah", "Hamidullah (FR)"),
    ],
)
config.plugins.quranmizouh.font_size = ConfigInteger(default=32, limits=(22, 46))
config.plugins.quranmizouh.storage_path = ConfigSelection(
    default="/media/hdd/QuranMizouh",
    choices=[
        ("/media/hdd/QuranMizouh", "/media/hdd/QuranMizouh"),
        ("/media/usb/QuranMizouh", "/media/usb/QuranMizouh"),
        ("/tmp/QuranMizouh", "/tmp/QuranMizouh"),
    ],
)

MUSHAF_W = 576
MUSHAF_H = 824
PAGE_TURN_LEAD_SEC = 1.2

DIACRITICS_RE = re.compile(r"[\u064B-\u065F\u0670\u06D6-\u06ED\s]+")


def strip_diacritics(text):
    return DIACRITICS_RE.sub("", text or "")


class QuranMizouhMainScreen(Screen):
    def __init__(self, session, restore_state=None):
        self.skin_theme = config.plugins.quranmizouh.skin_theme.value
        self.skin = build_main_skin(self.skin_theme)
        Screen.__init__(self, session)

        self.session = session
        self.prev_service = (restore_state or {}).get("prev_service") or self.session.nav.getCurrentlyPlayingServiceReference()
        self.api = QuranAPI()
        self.offline = OfflineManager(config.plugins.quranmizouh.storage_path.value)
        self.updater = PluginAutoUpdater()
        self.locale = LocaleLoader(config.plugins.quranmizouh.language.value)
        self.picload = ePicLoad()

        # Restore persistent Auto-Resume listening position (last_reciter, last_surah, last_ayah)
        saved_reciter_id = (restore_state or {}).get("reciter_id") or (config.plugins.quranmizouh.last_reciter.value or "").strip()
        saved_surah = (restore_state or {}).get("surah") or int(config.plugins.quranmizouh.last_surah.value or 1)
        saved_ayah = (restore_state or {}).get("ayah") or int(config.plugins.quranmizouh.last_ayah.value or 1)
        saved_riwaya = (restore_state or {}).get("riwaya") or config.plugins.quranmizouh.riwaya.value

        matched_global = self.api.find_reciter_by_id(saved_reciter_id) if saved_reciter_id else None
        if matched_global and not restore_state:
            saved_riwaya = matched_global.get("riwaya") or saved_riwaya

        self.riwaya = saved_riwaya
        self.show_mushaf = config.plugins.quranmizouh.show_mushaf.value
        self.mushaf_mode = config.plugins.quranmizouh.mushaf_mode.value
        self.active_pane = "surahs"
        self.current_surah = max(1, min(114, saved_surah))
        self.current_ayah = max(1, saved_ayah)
        self.current_page = SURAHS_LIST[self.current_surah - 1].get("page", 1)
        self.ayahs_data = []
        self.tafsirs_data = []
        self.ayah_page_map = {}
        self.exact_timings = []
        self.ref_ratio_timings = []
        self.ayah_weight_ranges = []

        # Generation counters cancel stale background threads immediately during fast remote navigation
        self._surah_load_gen = 0
        self._play_gen = 0
        self._page_req_gen = 0
        self._last_decoded_page_num = None
        self._mushaf_text_loaded_surah = None
        self._pending_surah_payload = None
        self._pending_timings_payload = None
        self._pending_decoded_page = None
        self._pending_decoded_page_num = None
        self._pending_search_results = None

        # Explicit 3-state playback machine: "stopped" | "playing" | "paused"
        self.play_state = (restore_state or {}).get("play_state", "stopped")
        self.last_pos_sec = (restore_state or {}).get("last_pos_sec", 0.0)
        self.pending_resume_sec = None
        self.pending_resume_ayah = self.current_ayah if (self.current_ayah > 1 and not restore_state) else None
        self.pending_update_info = None
        self.pending_download_status = None
        self.is_downloading_offline = False
        self._closing_for_skin_reload = False

        self.reciters = self.api.get_reciters_by_riwaya(self.riwaya)
        self.current_reciter = next((r for r in self.reciters if r["id"] == saved_reciter_id), self.reciters[0])

        self["header_title"] = Label(f"قارئ القرآن - mizouh المتميز   v{PLUGIN_VERSION}")
        self["riwaya_label"] = Label("")
        self["reciter_title"] = Label("")
        self["surah_title"] = Label(self.locale.t("surahs"))
        self["reciter_list"] = MenuList([])
        self["surah_list"] = MenuList([])
        self["surah_banner"] = Label("")
        self["mushaf_page"] = Pixmap()
        self["mushaf_text"] = ScrollLabel("")
        self["active_ayah_label"] = Label("")
        self["audio_only_status"] = Label("")
        self["tafsir_text"] = ScrollLabel("")
        self["key_red"] = Label("إيقاف كلي")
        self["key_green"] = Label("تشغيل / إيقاف مؤقت")
        self["key_yellow"] = Label("إظهار / إخفاء المصحف")
        self["key_blue"] = Label("")
        self["status_bar"] = Label(f"v{PLUGIN_VERSION} · REC/TEXT للتحميل · MENU للقائمة")

        # Fast 300ms timer for smooth page-turning & Tafsir sync (lightweight CPU footprint)
        self.sync_timer = eTimer()
        self.sync_timer.callback.append(self.sync_page_from_playback)

        # Main-thread handoff timers (keep GUI 100% responsive with zero main-thread blocking!)
        self.page_ready_timer = eTimer()
        self.page_ready_timer.callback.append(self._decode_ready_page)

        self.surah_ready_timer = eTimer()
        self.surah_ready_timer.callback.append(self._apply_loaded_surah_payload)

        self.timings_ready_timer = eTimer()
        self.timings_ready_timer.callback.append(self._apply_loaded_timings_payload)

        self.search_ready_timer = eTimer()
        self.search_ready_timer.callback.append(self._apply_search_results)

        self.update_ui_timer = eTimer()
        self.update_ui_timer.callback.append(self._handle_update_check_result)

        self.download_ui_timer = eTimer()
        self.download_ui_timer.callback.append(self._handle_download_status_update)

        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evEOF: self.on_surah_finished,
        })

        # Dedicated high-priority ColorActions & MediaPlayerActions (ZERO EPGSelectActions collision on Blue!)
        self["color_actions"] = ActionMap(
            ["ColorActions", "MediaPlayerActions", "InfobarSeekActions"],
            {
                "red": self.stop_recitation,
                "green": self.toggle_play_pause,
                "yellow": self.toggle_mushaf_display,
                "blue": self.toggle_riwaya,
                "play": self.resume_or_play,
                "pause": self.pause_recitation,
                "playpause": self.toggle_play_pause,
                "pauseService": self.toggle_play_pause,
                "unPauseService": self.resume_or_play,
                "stop": self.stop_recitation,
            },
            -2,
        )

        # Background offline download mapped to REC and TEXT remote buttons
        self["download_actions"] = ActionMap(
            ["InfobarInstantRecord", "InfobarTeletextActions"],
            {
                "instantRecord": self.start_background_download,
                "startTeletext": self.start_background_download,
            },
            -2,
        )

        self["nav_actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "MenuActions", "ChannelSelectBaseActions"],
            {
                "cancel": self.exit_plugin,
                "ok": self.on_ok,
                "up": self.move_up,
                "down": self.move_down,
                "left": self.switch_pane_reciters,
                "right": self.switch_pane_surahs,
                "menu": self.open_menu_screen,
                "nextBouquet": self.next_ayah_seek,
                "prevBouquet": self.prev_ayah_seek,
            },
            -1,
        )

        # Separate lower-priority map strictly for INFO key search (never intercepts Blue!)
        self["info_actions"] = ActionMap(
            ["EPGSelectActions"],
            {
                "info": self.open_search,
            },
            0,
        )

        self.picload.PictureData.get().append(self.on_mushaf_decoded)
        self.onLayoutFinish.append(self.initialize_ui)

    def initialize_ui(self):
        # Fast scaler flag (0) drastically speeds up Mushaf PNG/JPG decoding on MIPS/ARM Enigma2 boxes!
        self.picload.setPara((MUSHAF_W, MUSHAF_H, 1, 1, False, 0, "#FAF6EC"))
        self.populate_lists(keep_current=True)
        self.update_display_mode(trigger_image=False)
        self.load_surah_content(self.current_surah)
        self._refresh_playback_labels()
        surah_name = SURAHS_LIST[self.current_surah - 1]["name_ar"]
        if self.current_surah > 1 or self.current_ayah > 1:
            self["status_bar"].setText(f"استئناف: سورة {surah_name} · آية {self.current_ayah}")
        if self.play_state == "playing":
            self.sync_timer.start(300, False)
        if config.plugins.quranmizouh.auto_update.value:
            self.start_background_update_check()

    def save_playback_position(self, flush_disk=False):
        """Persists last_reciter, last_surah, last_ayah & riwaya without blocking UI flash I/O."""
        try:
            config.plugins.quranmizouh.riwaya.value = self.riwaya
            config.plugins.quranmizouh.last_reciter.value = str(self.current_reciter.get("id", ""))
            config.plugins.quranmizouh.last_surah.value = max(1, min(114, int(self.current_surah)))
            config.plugins.quranmizouh.last_ayah.value = max(1, min(286, int(self.current_ayah)))
            config.plugins.quranmizouh.riwaya.save()
            config.plugins.quranmizouh.last_reciter.save()
            config.plugins.quranmizouh.last_surah.save()
            config.plugins.quranmizouh.last_ayah.save()
            if flush_disk:
                configfile.save()
        except Exception:
            pass

    def _refresh_playback_labels(self):
        if self.play_state == "playing":
            self["key_green"].setText("إيقاف مؤقت")
        elif self.play_state == "paused":
            self["key_green"].setText("استمرار التلاوة")
        else:
            self["key_green"].setText("تشغيل التلاوة")

        if self.riwaya == "hafs":
            self["key_blue"].setText("تحويل إلى ورش")
        else:
            self["key_blue"].setText("تحويل إلى حفص")

    def start_background_download(self):
        """Downloads active Surah audio MP3 + Surah text & Tafsir in background thread without freezing TV."""
        if self.is_downloading_offline:
            self["status_bar"].setText("جارٍ التحميل في الخلفية بالفعل...")
            return

        reciter = dict(self.current_reciter)
        surah_num = int(self.current_surah)
        surah_name = SURAHS_LIST[surah_num - 1]["name_ar"]
        tafsir_ed = config.plugins.quranmizouh.tafsir_edition.value

        existing_mp3 = self.offline.get_local_mp3(reciter["id"], surah_num)
        if existing_mp3 and os.path.exists(existing_mp3) and os.path.getsize(existing_mp3) > 8192:
            self["status_bar"].setText(f"✔ سورة {surah_name} محفوظة مسبقاً بدون إنترنت")
            return

        self.is_downloading_offline = True
        self["status_bar"].setText(f"⬇ جارٍ تحميل سورة {surah_name} في الخلفية...")

        def _dl_worker():
            try:
                self.api.fetch_surah_and_tafsir(surah_num, tafsir_ed, self.offline)
                q_url, _ = self.api.fetch_continuous_surah_stream(reciter, surah_num)
                mp3_url = q_url or self.api.build_audio_url(reciter, surah_num)
                saved_path = self.offline.download_surah(reciter["id"], surah_num, mp3_url)
                if saved_path:
                    self.pending_download_status = f"✔ تم حفظ سورة {surah_name} والتفسير بدون إنترنت"
                else:
                    self.pending_download_status = f"✖ تعذر تحميل سورة {surah_name} (تحقق من المساحة أو الإنترنت)"
            except Exception:
                self.pending_download_status = f"✖ خطأ أثناء تحميل سورة {surah_name}"
            finally:
                self.is_downloading_offline = False
                self.download_ui_timer.start(50, True)

        threading.Thread(target=_dl_worker, daemon=True).start()

    def _handle_download_status_update(self):
        msg = self.pending_download_status
        self.pending_download_status = None
        if msg:
            self["status_bar"].setText(msg)

    def start_background_update_check(self):
        def _worker():
            feed_updated = self.updater.sync_reciters_feed()
            update_info = self.updater.check_for_update()
            self.pending_update_info = {
                "feed_updated": feed_updated,
                "update": update_info,
            }
            self.update_ui_timer.start(150, True)

        threading.Thread(target=_worker, daemon=True).start()

    def _handle_update_check_result(self):
        result = self.pending_update_info
        self.pending_update_info = None
        if not result:
            return
        if result.get("feed_updated"):
            self.api.reload_catalog()
            self.populate_lists(keep_current=True)
        update_info = result.get("update")
        if not update_info:
            return

        new_ver = update_info.get("version", "")
        changelog = update_info.get("changelog_ar") or update_info.get("changelog_en") or ""
        force_auto = bool(update_info.get("force_auto_update", False))

        if force_auto and config.plugins.quranmizouh.auto_update.value:
            self["status_bar"].setText(f"جارٍ التحديث التلقائي إلى v{new_ver}...")
            self.apply_ota_update(update_info)
        else:
            msg = (
                f"يتوفر تحديث جديد لبلوجن قارئ القرآن - mizouh المتميز\n"
                f"الإصدار الحالي: v{PLUGIN_VERSION}  ←  الإصدار الجديد: v{new_ver}\n\n"
                f"{changelog}\n\n"
                f"هل تريد التحديث الآن وإعادة تشغيل الواجهة؟"
            )
            self.session.openWithCallback(
                lambda confirmed: self.apply_ota_update(update_info) if confirmed else None,
                MessageBox,
                msg,
                MessageBox.TYPE_YESNO,
            )

    def apply_ota_update(self, update_info):
        self.save_playback_position(flush_disk=True)
        ok, message = self.updater.download_and_install_update(update_info)
        if ok:
            self.session.openWithCallback(
                lambda _res=None: self.session.open(TryQuitMainloop, 3),
                MessageBox,
                f"{message}\nجارٍ إعادة تشغيل Enigma2 لتفعيل الإصدار v{update_info.get('version', '')}...",
                MessageBox.TYPE_INFO,
                timeout=3,
            )
        else:
            self["status_bar"].setText("تعذر التحديث التلقائي")
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=5)

    def on_mushaf_decoded(self, picInfo=None):
        ptr = self.picload.getData()
        if ptr is not None:
            self["mushaf_page"].instance.setPixmap(ptr)

    def populate_lists(self, keep_current=False):
        self.reciters = self.api.get_reciters_by_riwaya(self.riwaya)
        if not self.reciters:
            return
        if not keep_current or self.current_reciter["id"] not in [r["id"] for r in self.reciters]:
            self.current_reciter = self.reciters[0]

        riwaya_title = "رواية حفص عن عاصم" if self.riwaya == "hafs" else "رواية ورش عن نافع"
        self["reciter_title"].setText(f"قراء {riwaya_title} ({len(self.reciters)})")
        self["reciter_list"].setList([(r["name_ar"], r) for r in self.reciters])
        idx_rec = next((i for i, r in enumerate(self.reciters) if r["id"] == self.current_reciter["id"]), 0)
        try:
            self["reciter_list"].moveToIndex(idx_rec)
        except Exception:
            pass

        self["surah_list"].setList([(f"{s['number']:03d} - سورة {s['name_ar']}", s) for s in SURAHS_LIST])
        try:
            self["surah_list"].moveToIndex(max(0, self.current_surah - 1))
        except Exception:
            pass

        self["riwaya_label"].setText(f"{riwaya_title}  ·  {self.current_reciter['name_ar']}")
        self._refresh_playback_labels()

    def _populate_text_mushaf_lazy(self):
        """Populates heavy ScrollLabel only when user actually switches to text mode (0ms cost in image mode!)."""
        if self._mushaf_text_loaded_surah == self.current_surah:
            return
        if not self.ayahs_data:
            return
        mushaf_str = " ۝ ".join([f"{a['text']} ({a['num']})" for a in self.ayahs_data])
        self["mushaf_text"].setText(mushaf_str)
        self._mushaf_text_loaded_surah = self.current_surah

    def update_display_mode(self, trigger_image=True):
        if not self.show_mushaf:
            self["mushaf_page"].hide()
            self["mushaf_text"].hide()
            self["active_ayah_label"].hide()
            self["tafsir_text"].hide()
            self["audio_only_status"].show()
            surah_meta = SURAHS_LIST[self.current_surah - 1]
            riwaya_title = "حفص عن عاصم" if self.riwaya == "hafs" else "ورش عن نافع"
            self["audio_only_status"].setText(
                f"وضع الاستماع الصوتي (بدون إظهار المصحف)\n\nسورة {surah_meta['name_ar']}\nالقارئ: {self.current_reciter['name_ar']} ({riwaya_title})"
            )
            return

        self["audio_only_status"].hide()
        self["active_ayah_label"].show()
        self["tafsir_text"].show()

        if self.mushaf_mode == "image":
            self["mushaf_text"].hide()
            self["mushaf_page"].show()
            if trigger_image:
                self.render_mushaf_page_image(self.current_page)
        else:
            self["mushaf_page"].hide()
            self["mushaf_text"].show()
            self._populate_text_mushaf_lazy()

    def _prefetch_upcoming_pages(self, start_page, expected_gen):
        """Lightweight single-thread sequential prefetch for next 2 pages AFTER active page renders."""
        pages = [p for p in (start_page, start_page + 1) if 1 <= p <= 604]
        if not pages:
            return

        def _worker():
            time.sleep(0.25)
            for p in pages:
                if expected_gen != self._page_req_gen:
                    return
                if not self.offline.get_cached_mushaf_page(p):
                    self.offline.get_or_download_mushaf_page(p)

        threading.Thread(target=_worker, daemon=True).start()

    def render_mushaf_page_image(self, page_num, force=False):
        """Instant local-cache decode (<20ms) or non-blocking priority download for active Mushaf page."""
        if not self.show_mushaf or self.mushaf_mode != "image":
            return
        if not force and self._last_decoded_page_num == page_num:
            return

        self._page_req_gen += 1
        req_gen = self._page_req_gen

        cached_path = self.offline.get_cached_mushaf_page(page_num)
        if cached_path:
            self._last_decoded_page_num = page_num
            self.picload.startDecode(cached_path)
            self._prefetch_upcoming_pages(page_num + 1, req_gen)
            return

        def _dl_worker():
            path = self.offline.get_or_download_mushaf_page(page_num)
            if path and req_gen == self._page_req_gen and page_num == self.current_page:
                self._pending_decoded_page = path
                self._pending_decoded_page_num = page_num
                self.page_ready_timer.start(10, True)
                self._prefetch_upcoming_pages(page_num + 1, req_gen)

        threading.Thread(target=_dl_worker, daemon=True).start()

    def _decode_ready_page(self):
        path = self._pending_decoded_page
        page_num = self._pending_decoded_page_num
        self._pending_decoded_page = None
        self._pending_decoded_page_num = None
        if path and os.path.exists(path) and page_num == self.current_page:
            self._last_decoded_page_num = page_num
            self.picload.startDecode(path)

    def _compute_ayah_weight_ranges(self):
        self.ayah_weight_ranges = []
        if not self.ayahs_data:
            return
        intro = 14.0 if (self.current_surah != 1 and self.current_surah != 9) else 0.0
        weights = [max(8.0, float(len(strip_diacritics(a.get("text", "")))) + 2.5) for a in self.ayahs_data]
        total = intro + sum(weights)
        if total <= 0:
            return
        acc = intro
        for a, w in zip(self.ayahs_data, weights):
            s_r = acc / total
            acc += w
            e_r = acc / total
            self.ayah_weight_ranges.append((a["num"], s_r, e_r))

    def load_surah_content(self, surah_number):
        """
        100% NON-BLOCKING Surah loader:
        - Immediately renders the Surah's exact Madinah Mushaf start page (0ms delay!)
        - Uses instant RAM cache if already visited, or loads JSON/Tafsir in a background thread
        """
        self._surah_load_gen += 1
        load_gen = self._surah_load_gen
        surah_meta = SURAHS_LIST[surah_number - 1]
        tafsir_ed = config.plugins.quranmizouh.tafsir_edition.value

        # Step 1: Immediate Mushaf page flip using built-in 114-Surah page map (zero API wait!)
        known_start_page = surah_meta.get("page", 1)
        if self.current_ayah <= 1:
            self.current_page = known_start_page
            if self.show_mushaf and self.mushaf_mode == "image":
                self.render_mushaf_page_image(self.current_page)

        self["surah_banner"].setText(f"سورة {surah_meta['name_ar']}  ·  آية {self.current_ayah}  ·  صفحة {self.current_page}")

        # Step 2: Check instant RAM cache first (0ms hit when switching between Surahs!)
        mem_hit = self.api.get_cached_surah_mem(surah_number, tafsir_ed)
        if mem_hit is not None:
            self._finish_surah_load(surah_number, mem_hit[0], mem_hit[1])
            return

        self["active_ayah_label"].setText("جارٍ تحميل نص السورة والتفسير...")

        # Step 3: Fetch disk cache or network JSON asynchronously in background thread
        def _surah_worker():
            ayahs, tafsirs = self.api.fetch_surah_and_tafsir(surah_number, tafsir_ed, self.offline)
            if load_gen == self._surah_load_gen:
                self._pending_surah_payload = (load_gen, surah_number, ayahs, tafsirs)
                self.surah_ready_timer.start(10, True)

        threading.Thread(target=_surah_worker, daemon=True).start()

    def _apply_loaded_surah_payload(self):
        payload = self._pending_surah_payload
        self._pending_surah_payload = None
        if not payload:
            return
        load_gen, surah_number, ayahs, tafsirs = payload
        if load_gen != self._surah_load_gen or surah_number != self.current_surah:
            return
        self._finish_surah_load(surah_number, ayahs, tafsirs)

    def _finish_surah_load(self, surah_number, ayahs, tafsirs):
        self.ayahs_data = ayahs
        self.tafsirs_data = tafsirs
        if self.ayahs_data and self.current_ayah > len(self.ayahs_data):
            self.current_ayah = 1
        self.ayah_page_map = {a["num"]: a.get("page", 1) for a in self.ayahs_data}
        self._compute_ayah_weight_ranges()
        self._mushaf_text_loaded_surah = None
        if self.show_mushaf and self.mushaf_mode == "text":
            self._populate_text_mushaf_lazy()
        self.update_active_ui(force_page_reload=False)
        self["status_bar"].setText(f"v{PLUGIN_VERSION} · صفحة {self.current_page} · آية {self.current_ayah}")

    def update_active_ui(self, force_page_reload=False, override_page=None):
        if not self.ayahs_data:
            return
        idx = max(0, min(len(self.ayahs_data) - 1, self.current_ayah - 1))
        ayah = self.ayahs_data[idx]
        tafsir = self.tafsirs_data[idx] if idx < len(self.tafsirs_data) else {"text": ""}
        new_page = override_page if override_page is not None else ayah.get("page", self.current_page)
        page_changed = force_page_reload or (new_page != self.current_page) or (self._last_decoded_page_num != new_page)
        self.current_page = new_page

        surah_meta = SURAHS_LIST[self.current_surah - 1]
        self["surah_banner"].setText(f"سورة {surah_meta['name_ar']}  ·  آية {ayah['num']}  ·  صفحة {self.current_page}")
        self["active_ayah_label"].setText(f"{ayah['text']} ۝{ayah['num']}")
        self["tafsir_text"].setText(f"التفسير:\n{tafsir['text']}")
        if self.show_mushaf and self.mushaf_mode == "image" and page_changed:
            self.render_mushaf_page_image(self.current_page, force=force_page_reload)

    def play_continuous_surah(self, resume_sec=None, resume_ayah=None):
        """
        Starts full-Surah playback INSTANTLY (<10ms) with ZERO blocking API calls!
        Exact verse timings & reference ratios load silently in a background thread.
        """
        self.sync_timer.stop()
        self._play_gen += 1
        play_gen = self._play_gen
        self.exact_timings = []
        self.ref_ratio_timings = []

        reciter = dict(self.current_reciter)
        surah_num = int(self.current_surah)
        local_mp3 = self.offline.get_local_mp3(reciter["id"], surah_num)

        if local_mp3 and os.path.exists(local_mp3) and os.path.getsize(local_mp3) > 8192:
            url = local_mp3
            is_local = True
            source_label = f"تشغيل محلي · {reciter['name_ar']}"
        else:
            url = self.api.build_audio_url(reciter, surah_num)
            is_local = False
            riwaya_short = "حفص" if self.riwaya == "hafs" else "ورش"
            source_label = f"{riwaya_short} · {reciter['name_ar']}"

        # Play audio immediately — zero waiting for api.quran.com!
        sref = eServiceReference(4097, 0, url)
        sref.setName(f"سورة {SURAHS_LIST[surah_num - 1]['name_ar']} - {reciter['name_ar']}")
        self.session.nav.stopService()
        self.session.nav.playService(sref)
        self.play_state = "playing"
        self.pending_resume_sec = resume_sec
        self.pending_resume_ayah = resume_ayah
        if resume_sec is None and resume_ayah is None:
            self.current_ayah = 1
            self.last_pos_sec = 0.0
        elif resume_ayah is not None:
            self.current_ayah = resume_ayah

        self.save_playback_position(flush_disk=False)
        self.update_active_ui()
        self._refresh_playback_labels()
        self["status_bar"].setText(source_label)
        self.sync_timer.start(300, False)

        # Load exact or reference timing ratios in background thread for pinpoint page turns
        def _timings_worker():
            exact = []
            ratios = []
            if not is_local and reciter.get("quran_com_id", 0):
                _q_url, exact = self.api.fetch_continuous_surah_stream(reciter, surah_num)
            if not exact:
                ratios = self.api.fetch_reference_ratios(surah_num)
            if play_gen == self._play_gen:
                self._pending_timings_payload = (play_gen, exact, ratios)
                self.timings_ready_timer.start(20, True)

        threading.Thread(target=_timings_worker, daemon=True).start()

    def _apply_loaded_timings_payload(self):
        payload = self._pending_timings_payload
        self._pending_timings_payload = None
        if not payload:
            return
        play_gen, exact, ratios = payload
        if play_gen != self._play_gen:
            return
        self.exact_timings = exact or []
        self.ref_ratio_timings = ratios or []

    def sync_page_from_playback(self):
        if self.play_state != "playing":
            return
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        if not seek:
            return
        pos_tuple = seek.getPlayPosition()
        if not pos_tuple or pos_tuple[0] != 0:
            return
        pos_sec = pos_tuple[1] / 90000.0

        if self.pending_resume_sec is not None and pos_sec >= 0.1:
            target = self.pending_resume_sec
            self.pending_resume_sec = None
            seek.seekTo(int(target * 90000))
            return

        if self.pending_resume_ayah is not None and pos_sec >= 0.1:
            target_a = self.pending_resume_ayah
            self.pending_resume_ayah = None
            self._seek_to_ayah(target_a)
            return

        self.last_pos_sec = pos_sec
        matched_ayah = None
        lead_page = None

        if self.exact_timings:
            for item in self.exact_timings:
                if item["start"] <= pos_sec < item["end"]:
                    matched_ayah = item["ayah"]
                    break
            lead_sec = pos_sec + PAGE_TURN_LEAD_SEC
            for item in self.exact_timings:
                if item["start"] <= lead_sec < item["end"]:
                    upcoming_page = self.ayah_page_map.get(item["ayah"])
                    if upcoming_page and upcoming_page > self.current_page:
                        lead_page = upcoming_page
                    break
        else:
            len_tuple = seek.getLength()
            if len_tuple and len_tuple[0] == 0 and len_tuple[1] > 0:
                total_sec = len_tuple[1] / 90000.0
                progress = pos_sec / total_sec
                lead_progress = min(1.0, (pos_sec + PAGE_TURN_LEAD_SEC) / total_sec)
                ratios = self.ref_ratio_timings if self.ref_ratio_timings else self.ayah_weight_ranges
                for a_num, s_r, e_r in ratios:
                    if s_r <= progress <= e_r:
                        matched_ayah = a_num
                        break
                for a_num, s_r, e_r in ratios:
                    if s_r <= lead_progress <= e_r:
                        upcoming_page = self.ayah_page_map.get(a_num)
                        if upcoming_page and upcoming_page > self.current_page:
                            lead_page = upcoming_page
                        break

        if matched_ayah is not None and matched_ayah != self.current_ayah:
            self.current_ayah = matched_ayah
            self.save_playback_position(flush_disk=False)
            self.update_active_ui(override_page=lead_page)
        elif lead_page is not None and lead_page != self.current_page:
            self.update_active_ui(override_page=lead_page)

    def _seek_to_ayah(self, target_ayah):
        self.current_ayah = target_ayah
        self.save_playback_position(flush_disk=False)
        self.update_active_ui()
        service = self.session.nav.getCurrentService()
        seek = service and service.seek()
        if not seek:
            return
        target_sec = None
        if self.exact_timings:
            for item in self.exact_timings:
                if item["ayah"] == target_ayah:
                    target_sec = item["start"]
                    break
        else:
            len_tuple = seek.getLength()
            if len_tuple and len_tuple[0] == 0 and len_tuple[1] > 0:
                total_sec = len_tuple[1] / 90000.0
                ratios = self.ref_ratio_timings if self.ref_ratio_timings else self.ayah_weight_ranges
                for a_num, s_r, _e_r in ratios:
                    if a_num == target_ayah:
                        target_sec = s_r * total_sec
                        break
        if target_sec is not None:
            seek.seekTo(int(target_sec * 90000))

    def on_surah_finished(self):
        if self.play_state != "playing":
            return
        if self.current_surah < 114:
            self.current_surah += 1
            self.current_ayah = 1
            try:
                self["surah_list"].moveToIndex(self.current_surah - 1)
            except Exception:
                pass
            self.save_playback_position(flush_disk=False)
            self.load_surah_content(self.current_surah)
            self.play_continuous_surah()

    def next_ayah_seek(self):
        if self.current_ayah < len(self.ayahs_data):
            self._seek_to_ayah(self.current_ayah + 1)

    def prev_ayah_seek(self):
        if self.current_ayah > 1:
            self._seek_to_ayah(self.current_ayah - 1)

    def pause_recitation(self):
        if self.play_state != "playing":
            return
        service = self.session.nav.getCurrentService()
        pauseable = service and service.pause()
        if pauseable:
            pauseable.pause()
            self.play_state = "paused"
            self.sync_timer.stop()
            self.save_playback_position(flush_disk=False)
            self._refresh_playback_labels()
            self["status_bar"].setText("إيقاف مؤقت — اضغط الأخضر للاستمرار")

    def resume_or_play(self):
        if self.play_state == "playing":
            return
        if self.play_state == "paused":
            service = self.session.nav.getCurrentService()
            pauseable = service and service.pause()
            if pauseable:
                pauseable.unpause()
                self.play_state = "playing"
                self.sync_timer.start(300, False)
                self._refresh_playback_labels()
                self["status_bar"].setText(f"مستمر · {self.current_reciter['name_ar']}")
                return
            self.play_continuous_surah(resume_sec=self.last_pos_sec)
            return
        resume_a = self.pending_resume_ayah or (self.current_ayah if self.current_ayah > 1 else None)
        self.play_continuous_surah(resume_ayah=resume_a)

    def toggle_play_pause(self):
        if self.play_state == "playing":
            self.pause_recitation()
        elif self.play_state == "paused":
            self.resume_or_play()
        else:
            self.resume_or_play()

    def stop_recitation(self):
        self.sync_timer.stop()
        self.session.nav.stopService()
        self.play_state = "stopped"
        self.last_pos_sec = 0.0
        self.save_playback_position(flush_disk=False)
        self._refresh_playback_labels()
        self["status_bar"].setText("تم الإيقاف الكلي")

    def toggle_mushaf_display(self):
        self.show_mushaf = not self.show_mushaf
        config.plugins.quranmizouh.show_mushaf.value = self.show_mushaf
        config.plugins.quranmizouh.show_mushaf.save()
        self.update_display_mode()

    def toggle_riwaya(self):
        """Reliably switches Hafs <-> Warsh, updates reciter list to index 0, saves position, and plays immediately!"""
        next_riwaya = "warsh" if self.riwaya == "hafs" else "hafs"
        next_reciters = self.api.get_reciters_by_riwaya(next_riwaya)
        if not next_reciters:
            self["status_bar"].setText("تعذر تحميل قائمة القراء لهذه الرواية")
            return
        self.riwaya = next_riwaya
        self.reciters = next_reciters
        self.current_reciter = self.reciters[0]
        self.save_playback_position(flush_disk=False)
        self.populate_lists(keep_current=False)
        riwaya_title = "حفص عن عاصم" if self.riwaya == "hafs" else "ورش عن نافع"
        self["status_bar"].setText(f"تم التحويل إلى {riwaya_title} · {self.current_reciter['name_ar']}")
        self.play_continuous_surah()

    def switch_pane_reciters(self):
        self.active_pane = "reciters"

    def switch_pane_surahs(self):
        self.active_pane = "surahs"

    def move_up(self):
        if self.active_pane == "reciters":
            self["reciter_list"].up()
        else:
            self["surah_list"].up()

    def move_down(self):
        if self.active_pane == "reciters":
            self["reciter_list"].down()
        else:
            self["surah_list"].down()

    def on_ok(self):
        if self.active_pane == "reciters":
            sel = self["reciter_list"].getCurrent()
            if sel:
                self.current_reciter = sel[1]
                self.save_playback_position(flush_disk=False)
                riwaya_title = "رواية حفص عن عاصم" if self.riwaya == "hafs" else "رواية ورش عن نافع"
                self["riwaya_label"].setText(f"{riwaya_title}  ·  {self.current_reciter['name_ar']}")
                self.play_continuous_surah()
        else:
            sel = self["surah_list"].getCurrent()
            if sel:
                self.current_surah = sel[1]["number"]
                self.current_ayah = 1
                self.pending_resume_ayah = None
                self.save_playback_position(flush_disk=False)
                self.load_surah_content(self.current_surah)
                self.play_continuous_surah()

    def open_search(self):
        self.session.openWithCallback(self.execute_search, VirtualKeyBoard, title="البحث المتقدم في القرآن الكريم", text="")

    def execute_search(self, keyword):
        if not keyword:
            return
        self["status_bar"].setText(f"جارٍ البحث عن: {keyword}...")

        def _search_worker():
            results = self.api.search_verses(keyword)
            self._pending_search_results = results
            self.search_ready_timer.start(20, True)

        threading.Thread(target=_search_worker, daemon=True).start()

    def _apply_search_results(self):
        results = self._pending_search_results
        self._pending_search_results = None
        if not results:
            self["status_bar"].setText("لم يتم العثور على نتائج مطابقة")
            self.session.open(MessageBox, "لم يتم العثور على نتائج مطابقة.", MessageBox.TYPE_INFO, timeout=4)
            return
        first = results[0]
        self.current_surah = first["surah"]
        self.current_ayah = first["ayah"]
        try:
            self["surah_list"].moveToIndex(max(0, self.current_surah - 1))
        except Exception:
            pass
        self.save_playback_position(flush_disk=False)
        self.load_surah_content(self.current_surah)
        self.play_continuous_surah(resume_ayah=first["ayah"])

    def open_menu_screen(self):
        """Opens the themed MENU screen with Background Download, 4 Skins & GitHub OTA Updater."""
        surah_name = SURAHS_LIST[self.current_surah - 1]["name_ar"]
        self.session.openWithCallback(
            self._on_menu_closed,
            QuranMizouhMenuScreen,
            self.updater,
            surah_name,
        )

    def _on_menu_closed(self, action=None):
        if action == "download_offline":
            self.start_background_download()
            return
        if action == "update_plugin":
            self.check_update_now()
            return
        if action == "update_reciters":
            ok = self.updater.sync_reciters_feed()
            self.api.reload_catalog()
            self.populate_lists(keep_current=True)
            msg = "تم تحديث قائمة القراء من GitHub بنجاح!" if ok else "تعذر الاتصال بـ GitHub، القائمة المحلية تعمل بشكل طبيعي."
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=4)
            return
        if action == "saved":
            new_skin = config.plugins.quranmizouh.skin_theme.value
            self.show_mushaf = config.plugins.quranmizouh.show_mushaf.value
            self.mushaf_mode = config.plugins.quranmizouh.mushaf_mode.value
            self.offline = OfflineManager(config.plugins.quranmizouh.storage_path.value)
            new_riwaya = config.plugins.quranmizouh.riwaya.value
            if new_riwaya != self.riwaya:
                self.riwaya = new_riwaya
                self.populate_lists(keep_current=False)
            self.save_playback_position(flush_disk=True)

            if new_skin != self.skin_theme:
                state = {
                    "prev_service": self.prev_service,
                    "riwaya": self.riwaya,
                    "reciter_id": self.current_reciter["id"],
                    "surah": self.current_surah,
                    "ayah": self.current_ayah,
                    "play_state": self.play_state,
                    "last_pos_sec": self.last_pos_sec,
                }
                self._closing_for_skin_reload = True
                self._stop_all_timers()
                self.close()
                self.session.open(QuranMizouhMainScreen, restore_state=state)
                return

            self.update_display_mode()

    def check_update_now(self):
        self["status_bar"].setText("جارٍ فحص التحديثات من GitHub...")
        self.updater.sync_reciters_feed()
        self.api.reload_catalog()
        self.populate_lists(keep_current=True)
        update_info = self.updater.check_for_update()
        if update_info:
            self.apply_ota_update(update_info)
        else:
            self["status_bar"].setText(f"v{PLUGIN_VERSION} · محدث لأحدث إصدار")
            self.session.open(
                MessageBox,
                f"البلوجن محدث بالفعل لأحدث إصدار (v{PLUGIN_VERSION})\nالمستودع: {GITHUB_USER}/{GITHUB_REPO}",
                MessageBox.TYPE_INFO,
                timeout=4,
            )

    def _stop_all_timers(self):
        for t in (
            self.sync_timer,
            self.page_ready_timer,
            self.surah_ready_timer,
            self.timings_ready_timer,
            self.search_ready_timer,
            self.update_ui_timer,
            self.download_ui_timer,
        ):
            try:
                t.stop()
            except Exception:
                pass

    def exit_plugin(self):
        self._stop_all_timers()
        self.save_playback_position(flush_disk=True)
        if not self._closing_for_skin_reload:
            self.session.nav.stopService()
            if self.prev_service:
                self.session.nav.playService(self.prev_service)
        self.close()


class QuranMizouhMenuScreen(ConfigListScreen, Screen):
    """Dedicated MENU Screen: Offline Surah Download + 4 Live FullHD Skins + GitHub OTA Updates."""

    def __init__(self, session, updater=None, current_surah_name="الفاتحة"):
        self.skin = build_menu_skin(config.plugins.quranmizouh.skin_theme.value)
        Screen.__init__(self, session)
        self.updater = updater
        self._download_entry = getConfigListEntry(
            f"⬇ تحميل سورة ({current_surah_name}) للاستماع بدون إنترنت",
            ConfigNothing(),
        )

        entries = [
            self._download_entry,
            getConfigListEntry("مظهر الواجهة (السكين / Skin)", config.plugins.quranmizouh.skin_theme),
            getConfigListEntry("التحديث التلقائي الدوري عبر GitHub", config.plugins.quranmizouh.auto_update),
            getConfigListEntry("الرواية الافتراضية (حفص / ورش)", config.plugins.quranmizouh.riwaya),
            getConfigListEntry("إظهار المصحف الشريف أثناء التلاوة", config.plugins.quranmizouh.show_mushaf),
            getConfigListEntry("نمط المصحف (صورة حقيقية / نص)", config.plugins.quranmizouh.mushaf_mode),
            getConfigListEntry("مصدر التفسير / الترجمة", config.plugins.quranmizouh.tafsir_edition),
            getConfigListEntry("لغة الواجهة / Language", config.plugins.quranmizouh.language),
            getConfigListEntry("حجم الخط القرآني", config.plugins.quranmizouh.font_size),
            getConfigListEntry("مجلد التحميل بدون إنترنت", config.plugins.quranmizouh.storage_path),
        ]
        ConfigListScreen.__init__(self, entries)

        self["menu_title"] = Label(f"قائمة قارئ القرآن - mizouh المتميز   ·   الإصدار v{PLUGIN_VERSION}")
        self["repo_info"] = Label(f"مستودع التحديثات: github.com/{GITHUB_USER}/{GITHUB_REPO}")
        self["update_status"] = Label("OK على الخيار الأول للتحميل بدون إنترنت · الأخضر لتطبيق السكين · الأصفر للتحديث من GitHub")
        self["btn_red"] = Label("إغلاق")
        self["btn_green"] = Label("حفظ وتطبيق السكين")
        self["btn_yellow"] = Label("تحديث البلوجن من GitHub")
        self["btn_blue"] = Label("تحديث القراء فقط")

        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "save": self.save_settings,
            "ok": self.on_ok_pressed,
            "green": self.save_settings,
            "yellow": self.trigger_plugin_update,
            "blue": self.trigger_reciters_update,
            "red": lambda: self.close(None),
            "cancel": lambda: self.close(None),
        }, -2)

    def on_ok_pressed(self):
        cur = self["config"].getCurrent()
        if cur is self._download_entry:
            self.close("download_offline")
            return
        self.save_settings()

    def save_settings(self):
        for item in self["config"].list:
            if hasattr(item[1], "save"):
                item[1].save()
        configfile.save()
        self.close("saved")

    def trigger_plugin_update(self):
        self.close("update_plugin")

    def trigger_reciters_update(self):
        self.close("update_reciters")


def main(session, **kwargs):
    session.open(QuranMizouhMainScreen)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="قارئ القرآن - mizouh",
            description=f"قارئ القرآن - mizouh المتميز v{PLUGIN_VERSION} - تلاوة متصلة وسريعة (حفص وورش) مع المصحف الحقيقي و4 سكينات",
            where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
            icon="plugin.png",
            fnc=main,
        )
    ]
