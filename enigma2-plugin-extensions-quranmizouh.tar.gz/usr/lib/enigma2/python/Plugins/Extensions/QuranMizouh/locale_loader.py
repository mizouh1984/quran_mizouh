# -*- coding: utf-8 -*-
import json
import os

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))


class LocaleLoader:
    def __init__(self, lang="ar"):
        self.lang = lang
        path = os.path.join(PLUGIN_DIR, "locale", "translations.json")
        self.strings = {}
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.strings = data.get(lang, data.get("ar", {}))

    def t(self, key):
        return self.strings.get(key, key)
