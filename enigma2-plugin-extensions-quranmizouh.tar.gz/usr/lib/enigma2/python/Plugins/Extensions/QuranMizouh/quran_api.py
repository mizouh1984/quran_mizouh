# -*- coding: utf-8 -*-
import json
import os
import urllib.request
import urllib.parse

from .version import PLUGIN_VERSION

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_FILE = os.path.join(PLUGIN_DIR, "reciters_feed.json")

SURAHS_LIST = [
    {"number": 1, "name_ar": "الفاتحة", "ayahs": 7},
    {"number": 2, "name_ar": "البقرة", "ayahs": 286},
    {"number": 3, "name_ar": "آل عمران", "ayahs": 200},
    {"number": 4, "name_ar": "النساء", "ayahs": 176},
    {"number": 5, "name_ar": "المائدة", "ayahs": 120},
    {"number": 6, "name_ar": "الأنعام", "ayahs": 165},
    {"number": 7, "name_ar": "الأعراف", "ayahs": 206},
    {"number": 8, "name_ar": "الأنفال", "ayahs": 75},
    {"number": 9, "name_ar": "التوبة", "ayahs": 129},
    {"number": 10, "name_ar": "يونس", "ayahs": 109},
    {"number": 11, "name_ar": "هود", "ayahs": 123},
    {"number": 12, "name_ar": "يوسف", "ayahs": 111},
    {"number": 13, "name_ar": "الرعد", "ayahs": 43},
    {"number": 14, "name_ar": "إبراهيم", "ayahs": 52},
    {"number": 15, "name_ar": "الحجر", "ayahs": 99},
    {"number": 16, "name_ar": "النحل", "ayahs": 128},
    {"number": 17, "name_ar": "الإسراء", "ayahs": 111},
    {"number": 18, "name_ar": "الكهف", "ayahs": 110},
    {"number": 19, "name_ar": "مريم", "ayahs": 98},
    {"number": 20, "name_ar": "طه", "ayahs": 135},
    {"number": 21, "name_ar": "الأنبياء", "ayahs": 112},
    {"number": 22, "name_ar": "الحج", "ayahs": 78},
    {"number": 23, "name_ar": "المؤمنون", "ayahs": 118},
    {"number": 24, "name_ar": "النور", "ayahs": 64},
    {"number": 25, "name_ar": "الفرقان", "ayahs": 77},
    {"number": 26, "name_ar": "الشعراء", "ayahs": 227},
    {"number": 27, "name_ar": "النمل", "ayahs": 93},
    {"number": 28, "name_ar": "القصص", "ayahs": 88},
    {"number": 29, "name_ar": "العنكبوت", "ayahs": 69},
    {"number": 30, "name_ar": "الروم", "ayahs": 60},
    {"number": 31, "name_ar": "لقمان", "ayahs": 34},
    {"number": 32, "name_ar": "السجدة", "ayahs": 30},
    {"number": 33, "name_ar": "الأحزاب", "ayahs": 73},
    {"number": 34, "name_ar": "سبأ", "ayahs": 54},
    {"number": 35, "name_ar": "فاطر", "ayahs": 45},
    {"number": 36, "name_ar": "يس", "ayahs": 83},
    {"number": 37, "name_ar": "الصافات", "ayahs": 182},
    {"number": 38, "name_ar": "ص", "ayahs": 88},
    {"number": 39, "name_ar": "الزمر", "ayahs": 75},
    {"number": 40, "name_ar": "غافر", "ayahs": 85},
    {"number": 41, "name_ar": "فصلت", "ayahs": 54},
    {"number": 42, "name_ar": "الشورى", "ayahs": 53},
    {"number": 43, "name_ar": "الزخرف", "ayahs": 89},
    {"number": 44, "name_ar": "الدخان", "ayahs": 59},
    {"number": 45, "name_ar": "الجاثية", "ayahs": 37},
    {"number": 46, "name_ar": "الأحقاف", "ayahs": 35},
    {"number": 47, "name_ar": "محمد", "ayahs": 38},
    {"number": 48, "name_ar": "الفتح", "ayahs": 29},
    {"number": 49, "name_ar": "الحجرات", "ayahs": 18},
    {"number": 50, "name_ar": "ق", "ayahs": 45},
    {"number": 51, "name_ar": "الذاريات", "ayahs": 60},
    {"number": 52, "name_ar": "الطور", "ayahs": 49},
    {"number": 53, "name_ar": "النجم", "ayahs": 62},
    {"number": 54, "name_ar": "القمر", "ayahs": 55},
    {"number": 55, "name_ar": "الرحمن", "ayahs": 78},
    {"number": 56, "name_ar": "الواقعة", "ayahs": 96},
    {"number": 57, "name_ar": "الحديد", "ayahs": 29},
    {"number": 58, "name_ar": "المجادلة", "ayahs": 22},
    {"number": 59, "name_ar": "الحشر", "ayahs": 24},
    {"number": 60, "name_ar": "الممتحنة", "ayahs": 13},
    {"number": 61, "name_ar": "الصف", "ayahs": 14},
    {"number": 62, "name_ar": "الجمعة", "ayahs": 11},
    {"number": 63, "name_ar": "المنافقون", "ayahs": 11},
    {"number": 64, "name_ar": "التغابن", "ayahs": 18},
    {"number": 65, "name_ar": "الطلاق", "ayahs": 12},
    {"number": 66, "name_ar": "التحريم", "ayahs": 12},
    {"number": 67, "name_ar": "الملك", "ayahs": 30},
    {"number": 68, "name_ar": "القلم", "ayahs": 52},
    {"number": 69, "name_ar": "الحاقة", "ayahs": 52},
    {"number": 70, "name_ar": "المعارج", "ayahs": 44},
    {"number": 71, "name_ar": "نوح", "ayahs": 28},
    {"number": 72, "name_ar": "الجن", "ayahs": 28},
    {"number": 73, "name_ar": "المزمل", "ayahs": 20},
    {"number": 74, "name_ar": "المدثر", "ayahs": 56},
    {"number": 75, "name_ar": "القيامة", "ayahs": 40},
    {"number": 76, "name_ar": "الإنسان", "ayahs": 31},
    {"number": 77, "name_ar": "المرسلات", "ayahs": 50},
    {"number": 78, "name_ar": "النبأ", "ayahs": 40},
    {"number": 79, "name_ar": "النازعات", "ayahs": 46},
    {"number": 80, "name_ar": "عبس", "ayahs": 42},
    {"number": 81, "name_ar": "التكوير", "ayahs": 29},
    {"number": 82, "name_ar": "الانفطار", "ayahs": 19},
    {"number": 83, "name_ar": "المطففين", "ayahs": 36},
    {"number": 84, "name_ar": "الانشقاق", "ayahs": 25},
    {"number": 85, "name_ar": "البروج", "ayahs": 22},
    {"number": 86, "name_ar": "الطارق", "ayahs": 17},
    {"number": 87, "name_ar": "الأعلى", "ayahs": 19},
    {"number": 88, "name_ar": "الغاشية", "ayahs": 26},
    {"number": 89, "name_ar": "الفجر", "ayahs": 30},
    {"number": 90, "name_ar": "البلد", "ayahs": 20},
    {"number": 91, "name_ar": "الشمس", "ayahs": 15},
    {"number": 92, "name_ar": "الليل", "ayahs": 21},
    {"number": 93, "name_ar": "الضحى", "ayahs": 11},
    {"number": 94, "name_ar": "الشرح", "ayahs": 8},
    {"number": 95, "name_ar": "التين", "ayahs": 8},
    {"number": 96, "name_ar": "العلق", "ayahs": 19},
    {"number": 97, "name_ar": "القدر", "ayahs": 5},
    {"number": 98, "name_ar": "البينة", "ayahs": 8},
    {"number": 99, "name_ar": "الزلزلة", "ayahs": 8},
    {"number": 100, "name_ar": "العاديات", "ayahs": 11},
    {"number": 101, "name_ar": "القارعة", "ayahs": 11},
    {"number": 102, "name_ar": "التكاثر", "ayahs": 8},
    {"number": 103, "name_ar": "العصر", "ayahs": 3},
    {"number": 104, "name_ar": "الهمزة", "ayahs": 9},
    {"number": 105, "name_ar": "الفيل", "ayahs": 5},
    {"number": 106, "name_ar": "قريش", "ayahs": 4},
    {"number": 107, "name_ar": "الماعون", "ayahs": 7},
    {"number": 108, "name_ar": "الكوثر", "ayahs": 3},
    {"number": 109, "name_ar": "الكافرون", "ayahs": 6},
    {"number": 110, "name_ar": "النصر", "ayahs": 3},
    {"number": 111, "name_ar": "المسد", "ayahs": 5},
    {"number": 112, "name_ar": "الإخلاص", "ayahs": 4},
    {"number": 113, "name_ar": "الفلق", "ayahs": 5},
    {"number": 114, "name_ar": "الناس", "ayahs": 6},
]


class QuranAPI:
    def __init__(self):
        self.reciters = []
        self.reload_catalog()

    def reload_catalog(self):
        if os.path.exists(CATALOG_FILE):
            with open(CATALOG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.reciters = data.get("reciters", [])

    def get_reciters_by_riwaya(self, riwaya="hafs"):
        return [r for r in self.reciters if r.get("riwaya") == riwaya]

    def build_audio_url(self, reciter, surah_number):
        base = reciter["server"].rstrip("/")
        return f"{base}/{surah_number:03d}.mp3"

    def fetch_continuous_surah_stream(self, reciter, surah_number):
        """Returns (continuous_mp3_url, ayah_timings) for zero-delay continuous recitation & auto page turning."""
        qid = reciter.get("quran_com_id", 0)
        if not qid:
            return None, []
        url = f"https://api.quran.com/api/v4/chapter_recitations/{qid}/{surah_number}?segments=true"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
            with urllib.request.urlopen(req, timeout=8) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
                af = payload.get("audio_file", {})
                audio_url = af.get("audio_url")
                raw_ts = af.get("timestamps", [])
                timings = []
                for ts in raw_ts:
                    parts = str(ts.get("verse_key", "0:0")).split(":")
                    if len(parts) != 2:
                        continue
                    timings.append({
                        "ayah": int(parts[1]),
                        "start": float(ts.get("timestamp_from", 0)) / 1000.0,
                        "end": float(ts.get("timestamp_to", 0)) / 1000.0,
                    })
                if audio_url and timings:
                    return audio_url, timings
        except Exception:
            pass
        return None, []

    def fetch_surah_and_tafsir(self, surah_number, tafsir_edition="ar.muyassar", offline_mgr=None):
        if offline_mgr:
            cached = offline_mgr.load_surah_json(surah_number, tafsir_edition)
            if cached:
                return cached["ayahs"], cached["tafsirs"]

        url = f"https://api.alquran.cloud/v1/surah/{surah_number}/editions/quran-uthmani,{tafsir_edition}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
                q_ayahs = [{"num": a["numberInSurah"], "text": a["text"], "page": a.get("page", 1)} for a in payload["data"][0]["ayahs"]]
                t_ayahs = [{"num": a["numberInSurah"], "text": a["text"]} for a in payload["data"][1]["ayahs"]]
                if offline_mgr:
                    offline_mgr.save_surah_json(surah_number, tafsir_edition, q_ayahs, t_ayahs)
                return q_ayahs, t_ayahs
        except Exception:
            return [{"num": 1, "text": "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", "page": 1}], [{"num": 1, "text": "تحقق من اتصال الإنترنت أو شغّل السور المحفوظة محلياً."}]

    def search_verses(self, keyword):
        encoded = urllib.parse.quote(keyword)
        url = f"https://api.alquran.cloud/v1/search/{encoded}/all/ar"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
                matches = payload.get("data", {}).get("matches", [])
                return [
                    {
                        "surah": m["surah"]["number"],
                        "surah_name": m["surah"]["name"],
                        "ayah": m["numberInSurah"],
                        "text": m["text"],
                    }
                    for m in matches[:40]
                ]
        except Exception:
            return []
