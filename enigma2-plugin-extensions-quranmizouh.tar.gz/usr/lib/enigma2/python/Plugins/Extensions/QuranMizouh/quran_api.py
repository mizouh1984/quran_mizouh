# -*- coding: utf-8 -*-
import json
import os
import urllib.request
import urllib.parse

from .version import PLUGIN_VERSION

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_FILE = os.path.join(PLUGIN_DIR, "reciters_feed.json")

SURAHS_LIST = [
    {"number": 1, "name_ar": "الفاتحة", "ayahs": 7, "page": 1},
    {"number": 2, "name_ar": "البقرة", "ayahs": 286, "page": 2},
    {"number": 3, "name_ar": "آل عمران", "ayahs": 200, "page": 50},
    {"number": 4, "name_ar": "النساء", "ayahs": 176, "page": 77},
    {"number": 5, "name_ar": "المائدة", "ayahs": 120, "page": 106},
    {"number": 6, "name_ar": "الأنعام", "ayahs": 165, "page": 128},
    {"number": 7, "name_ar": "الأعراف", "ayahs": 206, "page": 151},
    {"number": 8, "name_ar": "الأنفال", "ayahs": 75, "page": 177},
    {"number": 9, "name_ar": "التوبة", "ayahs": 129, "page": 187},
    {"number": 10, "name_ar": "يونس", "ayahs": 109, "page": 208},
    {"number": 11, "name_ar": "هود", "ayahs": 123, "page": 221},
    {"number": 12, "name_ar": "يوسف", "ayahs": 111, "page": 235},
    {"number": 13, "name_ar": "الرعد", "ayahs": 43, "page": 249},
    {"number": 14, "name_ar": "إبراهيم", "ayahs": 52, "page": 255},
    {"number": 15, "name_ar": "الحجر", "ayahs": 99, "page": 262},
    {"number": 16, "name_ar": "النحل", "ayahs": 128, "page": 267},
    {"number": 17, "name_ar": "الإسراء", "ayahs": 111, "page": 282},
    {"number": 18, "name_ar": "الكهف", "ayahs": 110, "page": 293},
    {"number": 19, "name_ar": "مريم", "ayahs": 98, "page": 305},
    {"number": 20, "name_ar": "طه", "ayahs": 135, "page": 312},
    {"number": 21, "name_ar": "الأنبياء", "ayahs": 112, "page": 322},
    {"number": 22, "name_ar": "الحج", "ayahs": 78, "page": 332},
    {"number": 23, "name_ar": "المؤمنون", "ayahs": 118, "page": 342},
    {"number": 24, "name_ar": "النور", "ayahs": 64, "page": 350},
    {"number": 25, "name_ar": "الفرقان", "ayahs": 77, "page": 359},
    {"number": 26, "name_ar": "الشعراء", "ayahs": 227, "page": 367},
    {"number": 27, "name_ar": "النمل", "ayahs": 93, "page": 377},
    {"number": 28, "name_ar": "القصص", "ayahs": 88, "page": 385},
    {"number": 29, "name_ar": "العنكبوت", "ayahs": 69, "page": 396},
    {"number": 30, "name_ar": "الروم", "ayahs": 60, "page": 404},
    {"number": 31, "name_ar": "لقمان", "ayahs": 34, "page": 411},
    {"number": 32, "name_ar": "السجدة", "ayahs": 30, "page": 415},
    {"number": 33, "name_ar": "الأحزاب", "ayahs": 73, "page": 418},
    {"number": 34, "name_ar": "سبأ", "ayahs": 54, "page": 428},
    {"number": 35, "name_ar": "فاطر", "ayahs": 45, "page": 434},
    {"number": 36, "name_ar": "يس", "ayahs": 83, "page": 440},
    {"number": 37, "name_ar": "الصافات", "ayahs": 182, "page": 446},
    {"number": 38, "name_ar": "ص", "ayahs": 88, "page": 453},
    {"number": 39, "name_ar": "الزمر", "ayahs": 75, "page": 458},
    {"number": 40, "name_ar": "غافر", "ayahs": 85, "page": 467},
    {"number": 41, "name_ar": "فصلت", "ayahs": 54, "page": 477},
    {"number": 42, "name_ar": "الشورى", "ayahs": 53, "page": 483},
    {"number": 43, "name_ar": "الزخرف", "ayahs": 89, "page": 489},
    {"number": 44, "name_ar": "الدخان", "ayahs": 59, "page": 496},
    {"number": 45, "name_ar": "الجاثية", "ayahs": 37, "page": 499},
    {"number": 46, "name_ar": "الأحقاف", "ayahs": 35, "page": 502},
    {"number": 47, "name_ar": "محمد", "ayahs": 38, "page": 507},
    {"number": 48, "name_ar": "الفتح", "ayahs": 29, "page": 511},
    {"number": 49, "name_ar": "الحجرات", "ayahs": 18, "page": 515},
    {"number": 50, "name_ar": "ق", "ayahs": 45, "page": 518},
    {"number": 51, "name_ar": "الذاريات", "ayahs": 60, "page": 520},
    {"number": 52, "name_ar": "الطور", "ayahs": 49, "page": 523},
    {"number": 53, "name_ar": "النجم", "ayahs": 62, "page": 526},
    {"number": 54, "name_ar": "القمر", "ayahs": 55, "page": 528},
    {"number": 55, "name_ar": "الرحمن", "ayahs": 78, "page": 531},
    {"number": 56, "name_ar": "الواقعة", "ayahs": 96, "page": 534},
    {"number": 57, "name_ar": "الحديد", "ayahs": 29, "page": 537},
    {"number": 58, "name_ar": "المجادلة", "ayahs": 22, "page": 542},
    {"number": 59, "name_ar": "الحشر", "ayahs": 24, "page": 545},
    {"number": 60, "name_ar": "الممتحنة", "ayahs": 13, "page": 549},
    {"number": 61, "name_ar": "الصف", "ayahs": 14, "page": 551},
    {"number": 62, "name_ar": "الجمعة", "ayahs": 11, "page": 553},
    {"number": 63, "name_ar": "المنافقون", "ayahs": 11, "page": 554},
    {"number": 64, "name_ar": "التغابن", "ayahs": 18, "page": 556},
    {"number": 65, "name_ar": "الطلاق", "ayahs": 12, "page": 558},
    {"number": 66, "name_ar": "التحريم", "ayahs": 12, "page": 560},
    {"number": 67, "name_ar": "الملك", "ayahs": 30, "page": 562},
    {"number": 68, "name_ar": "القلم", "ayahs": 52, "page": 564},
    {"number": 69, "name_ar": "الحاقة", "ayahs": 52, "page": 566},
    {"number": 70, "name_ar": "المعارج", "ayahs": 44, "page": 568},
    {"number": 71, "name_ar": "نوح", "ayahs": 28, "page": 570},
    {"number": 72, "name_ar": "الجن", "ayahs": 28, "page": 572},
    {"number": 73, "name_ar": "المزمل", "ayahs": 20, "page": 574},
    {"number": 74, "name_ar": "المدثر", "ayahs": 56, "page": 575},
    {"number": 75, "name_ar": "القيامة", "ayahs": 40, "page": 577},
    {"number": 76, "name_ar": "الإنسان", "ayahs": 31, "page": 578},
    {"number": 77, "name_ar": "المرسلات", "ayahs": 50, "page": 580},
    {"number": 78, "name_ar": "النبأ", "ayahs": 40, "page": 582},
    {"number": 79, "name_ar": "النازعات", "ayahs": 46, "page": 583},
    {"number": 80, "name_ar": "عبس", "ayahs": 42, "page": 585},
    {"number": 81, "name_ar": "التكوير", "ayahs": 29, "page": 586},
    {"number": 82, "name_ar": "الانفطار", "ayahs": 19, "page": 587},
    {"number": 83, "name_ar": "المطففين", "ayahs": 36, "page": 587},
    {"number": 84, "name_ar": "الانشقاق", "ayahs": 25, "page": 589},
    {"number": 85, "name_ar": "البروج", "ayahs": 22, "page": 590},
    {"number": 86, "name_ar": "الطارق", "ayahs": 17, "page": 591},
    {"number": 87, "name_ar": "الأعلى", "ayahs": 19, "page": 591},
    {"number": 88, "name_ar": "الغاشية", "ayahs": 26, "page": 592},
    {"number": 89, "name_ar": "الفجر", "ayahs": 30, "page": 593},
    {"number": 90, "name_ar": "البلد", "ayahs": 20, "page": 594},
    {"number": 91, "name_ar": "الشمس", "ayahs": 15, "page": 595},
    {"number": 92, "name_ar": "الليل", "ayahs": 21, "page": 595},
    {"number": 93, "name_ar": "الضحى", "ayahs": 11, "page": 596},
    {"number": 94, "name_ar": "الشرح", "ayahs": 8, "page": 596},
    {"number": 95, "name_ar": "التين", "ayahs": 8, "page": 597},
    {"number": 96, "name_ar": "العلق", "ayahs": 19, "page": 597},
    {"number": 97, "name_ar": "القدر", "ayahs": 5, "page": 598},
    {"number": 98, "name_ar": "البينة", "ayahs": 8, "page": 598},
    {"number": 99, "name_ar": "الزلزلة", "ayahs": 8, "page": 599},
    {"number": 100, "name_ar": "العاديات", "ayahs": 11, "page": 599},
    {"number": 101, "name_ar": "القارعة", "ayahs": 11, "page": 600},
    {"number": 102, "name_ar": "التكاثر", "ayahs": 8, "page": 600},
    {"number": 103, "name_ar": "العصر", "ayahs": 3, "page": 601},
    {"number": 104, "name_ar": "الهمزة", "ayahs": 9, "page": 601},
    {"number": 105, "name_ar": "الفيل", "ayahs": 5, "page": 601},
    {"number": 106, "name_ar": "قريش", "ayahs": 4, "page": 602},
    {"number": 107, "name_ar": "الماعون", "ayahs": 7, "page": 602},
    {"number": 108, "name_ar": "الكوثر", "ayahs": 3, "page": 602},
    {"number": 109, "name_ar": "الكافرون", "ayahs": 6, "page": 603},
    {"number": 110, "name_ar": "النصر", "ayahs": 3, "page": 603},
    {"number": 111, "name_ar": "المسد", "ayahs": 5, "page": 603},
    {"number": 112, "name_ar": "الإخلاص", "ayahs": 4, "page": 604},
    {"number": 113, "name_ar": "الفلق", "ayahs": 5, "page": 604},
    {"number": 114, "name_ar": "الناس", "ayahs": 6, "page": 604},
]

# Built-in fallback reciters (guarantees BOTH Hafs & Warsh always load reliably!)
BUILTIN_RECITERS = [
    {"id": "afasy-hafs", "name_ar": "مشاري راشد العفاسي", "name_en": "Mishary Rashid Alafasy", "riwaya": "hafs", "server": "https://server8.mp3quran.net/afs/", "quran_com_id": 7},
    {"id": "ajmy-hafs", "name_ar": "أحمد بن علي العجمي", "name_en": "Ahmad bin Ali Al-Ajmy", "riwaya": "hafs", "server": "https://server10.mp3quran.net/ajm/", "quran_com_id": 0},
    {"id": "abdulbasit-hafs", "name_ar": "عبد الباسط عبد الصمد (مرتل)", "name_en": "Abdul Basit (Murattal)", "riwaya": "hafs", "server": "https://server7.mp3quran.net/basit/", "quran_com_id": 2},
    {"id": "abdulbasit-mujawwad", "name_ar": "عبد الباسط عبد الصمد (مجود)", "name_en": "Abdul Basit (Mujawwad)", "riwaya": "hafs", "server": "https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/", "quran_com_id": 1},
    {"id": "husary-hafs", "name_ar": "محمود خليل الحصري (مرتل)", "name_en": "Al-Husary (Murattal)", "riwaya": "hafs", "server": "https://server13.mp3quran.net/husr/", "quran_com_id": 6},
    {"id": "husary-muallim", "name_ar": "محمود خليل الحصري (المعلم)", "name_en": "Al-Husary (Muallim)", "riwaya": "hafs", "server": "https://server13.mp3quran.net/husr/", "quran_com_id": 12},
    {"id": "minshawi-hafs", "name_ar": "محمد صديق المنشاوي (مرتل)", "name_en": "Al-Minshawi (Murattal)", "riwaya": "hafs", "server": "https://server10.mp3quran.net/minsh/", "quran_com_id": 9},
    {"id": "minshawi-mujawwad", "name_ar": "محمد صديق المنشاوي (مجود)", "name_en": "Al-Minshawi (Mujawwad)", "riwaya": "hafs", "server": "https://server10.mp3quran.net/minsh/Almusshaf-Al-Mojawwad/", "quran_com_id": 8},
    {"id": "sudais-hafs", "name_ar": "عبد الرحمن السديس", "name_en": "Abdul Rahman Al-Sudais", "riwaya": "hafs", "server": "https://server11.mp3quran.net/sds/", "quran_com_id": 3},
    {"id": "shuraim-hafs", "name_ar": "سعود الشريم", "name_en": "Saud Al-Shuraim", "riwaya": "hafs", "server": "https://server7.mp3quran.net/shur/", "quran_com_id": 10},
    {"id": "shatri-hafs", "name_ar": "أبو بكر الشاطري", "name_en": "Abu Bakr Al-Shatri", "riwaya": "hafs", "server": "https://server11.mp3quran.net/shatri/", "quran_com_id": 4},
    {"id": "rifai-hafs", "name_ar": "هاني الرفاعي", "name_en": "Hani Ar-Rifai", "riwaya": "hafs", "server": "https://server8.mp3quran.net/hani/", "quran_com_id": 5},
    {"id": "maher-hafs", "name_ar": "ماهر المعيقلي", "name_en": "Maher Al-Muaiqly", "riwaya": "hafs", "server": "https://server12.mp3quran.net/maher/", "quran_com_id": 0},
    {"id": "ghamdi-hafs", "name_ar": "سعد الغامدي", "name_en": "Saad Al-Ghamdi", "riwaya": "hafs", "server": "https://server7.mp3quran.net/s_gmd/", "quran_com_id": 0},
    {"id": "dosari-hafs", "name_ar": "ياسر الدوسري", "name_en": "Yasser Al-Dosari", "riwaya": "hafs", "server": "https://server11.mp3quran.net/yasser/", "quran_com_id": 0},
    {"id": "qatami-hafs", "name_ar": "ناصر القطامي", "name_en": "Nasser Al-Qatami", "riwaya": "hafs", "server": "https://server6.mp3quran.net/qtm/", "quran_com_id": 0},
    {"id": "fares-hafs", "name_ar": "فارس عباد", "name_en": "Fares Abbad", "riwaya": "hafs", "server": "https://server8.mp3quran.net/frs_a/", "quran_com_id": 0},
    {"id": "idris-hafs", "name_ar": "إدريس أبكر", "name_en": "Idris Abkar", "riwaya": "hafs", "server": "https://server6.mp3quran.net/abkr/", "quran_com_id": 0},
    {"id": "ayyub-hafs", "name_ar": "محمد أيوب", "name_en": "Muhammad Ayyub", "riwaya": "hafs", "server": "https://server8.mp3quran.net/ayyub/", "quran_com_id": 0},
    {"id": "hudhaify-hafs", "name_ar": "علي الحذيفي", "name_en": "Ali Al-Hudhaify", "riwaya": "hafs", "server": "https://server9.mp3quran.net/hthfi/", "quran_com_id": 0},
    {"id": "jaleel-hafs", "name_ar": "خالد الجليل", "name_en": "Khalid Al-Jaleel", "riwaya": "hafs", "server": "https://server10.mp3quran.net/jleel/", "quran_com_id": 0},
    {"id": "qazabri-warsh", "name_ar": "عمر القزابري", "name_en": "Omar Al-Qazabri", "riwaya": "warsh", "server": "https://server9.mp3quran.net/omar_warsh/", "quran_com_id": 0},
    {"id": "yassin-warsh", "name_ar": "ياسين الجزائري", "name_en": "Yassin Al-Jazaery", "riwaya": "warsh", "server": "https://server11.mp3quran.net/qari/", "quran_com_id": 0},
    {"id": "kouchi-warsh", "name_ar": "العيون الكوشي", "name_en": "Laayoun El-Kouchi", "riwaya": "warsh", "server": "https://server11.mp3quran.net/koshi/", "quran_com_id": 0},
    {"id": "abdulbasit-warsh", "name_ar": "عبد الباسط عبد الصمد (ورش)", "name_en": "Abdul Basit (Warsh)", "riwaya": "warsh", "server": "https://server10.mp3quran.net/basit_warsh/", "quran_com_id": 0},
    {"id": "husary-warsh", "name_ar": "محمود خليل الحصري (ورش)", "name_en": "Al-Husary (Warsh)", "riwaya": "warsh", "server": "https://server13.mp3quran.net/husr/Rewayat-Warsh-A-n-Nafi/", "quran_com_id": 0},
    {"id": "belalya-warsh", "name_ar": "رشيد بلعالية", "name_en": "Rachid Belalya", "riwaya": "warsh", "server": "https://server6.mp3quran.net/bl3/Rewayat-Warsh-A-n-Nafi/", "quran_com_id": 0},
    {"id": "ibrahim-dosari-warsh", "name_ar": "إبراهيم الدوسري (ورش)", "name_en": "Ibrahim Al-Dosari (Warsh)", "riwaya": "warsh", "server": "https://server10.mp3quran.net/ibrahim_dosri/Rewayat-Warsh-A-n-Nafi/", "quran_com_id": 0},
    {"id": "hsain-warsh", "name_ar": "عبد الحميد احساين (ورش)", "name_en": "Abdelhamid Hssain (Warsh)", "riwaya": "warsh", "server": "https://server12.mp3quran.net/hsn/", "quran_com_id": 0},
    {"id": "daif-warsh", "name_ar": "محمد السيد ضيف (ورش)", "name_en": "Mohamed Sayed Daif (Warsh)", "riwaya": "warsh", "server": "https://server11.mp3quran.net/m_daif/", "quran_com_id": 0},
    {"id": "souilass-warsh", "name_ar": "يونس اسويلص (ورش)", "name_en": "Younes Souilass (Warsh)", "riwaya": "warsh", "server": "https://server16.mp3quran.net/souilass/Rewayat-Warsh-A-n-Nafi/", "quran_com_id": 0},
]


class QuranAPI:
    def __init__(self):
        self.reciters = []
        self._ref_ratios_cache = {}
        self._timings_cache = {}
        self._surah_mem_cache = {}
        self._surah_mem_order = []
        self.reload_catalog()

    def reload_catalog(self):
        loaded = []
        if os.path.exists(CATALOG_FILE):
            try:
                with open(CATALOG_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    loaded = data.get("reciters", [])
            except Exception:
                loaded = []

        has_hafs = any(r.get("riwaya") == "hafs" for r in loaded)
        has_warsh = any(r.get("riwaya") == "warsh" for r in loaded)
        if has_hafs and has_warsh:
            self.reciters = loaded
        else:
            existing_ids = {r.get("id") for r in loaded}
            merged = list(loaded)
            for item in BUILTIN_RECITERS:
                if item["id"] not in existing_ids:
                    merged.append(item)
            self.reciters = merged

    def find_reciter_by_id(self, reciter_id):
        if not reciter_id:
            return None
        for r in self.reciters:
            if r.get("id") == reciter_id:
                return r
        return None

    def get_reciters_by_riwaya(self, riwaya="hafs"):
        target = str(riwaya or "hafs").strip().lower()
        return [r for r in self.reciters if str(r.get("riwaya", "")).strip().lower() == target]

    def build_audio_url(self, reciter, surah_number):
        base = reciter["server"].rstrip("/")
        return f"{base}/{surah_number:03d}.mp3"

    def get_cached_surah_mem(self, surah_number, tafsir_edition="ar.muyassar"):
        return self._surah_mem_cache.get((int(surah_number), str(tafsir_edition)))

    def _put_surah_mem(self, surah_number, tafsir_edition, ayahs, tafsirs):
        key = (int(surah_number), str(tafsir_edition))
        if key not in self._surah_mem_cache:
            self._surah_mem_order.append(key)
            if len(self._surah_mem_order) > 24:
                oldest = self._surah_mem_order.pop(0)
                self._surah_mem_cache.pop(oldest, None)
        self._surah_mem_cache[key] = (ayahs, tafsirs)

    def fetch_continuous_surah_stream(self, reciter, surah_number):
        """Returns (continuous_mp3_url, ayah_timings) with RAM caching for instant repeat switches."""
        qid = reciter.get("quran_com_id", 0)
        if not qid:
            return None, []
        cache_key = (int(qid), int(surah_number))
        if cache_key in self._timings_cache:
            return self._timings_cache[cache_key]
        url = f"https://api.quran.com/api/v4/chapter_recitations/{qid}/{surah_number}?segments=true"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
            with urllib.request.urlopen(req, timeout=6) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
                af = payload.get("audio_file", {})
                audio_url = af.get("audio_url")
                raw_ts = af.get("timestamps", [])
                timings = []
                for ts in raw_ts:
                    parts = str(ts.get("verse_key", "0:0")).split(":")
                    if len(parts) != 2:
                        continue
                    timings.append({
                        "ayah": int(parts[1]),
                        "start": float(ts.get("timestamp_from", 0)) / 1000.0,
                        "end": float(ts.get("timestamp_to", 0)) / 1000.0,
                    })
                if audio_url and timings:
                    self._timings_cache[cache_key] = (audio_url, timings)
                    return audio_url, timings
        except Exception:
            pass
        return None, []

    def fetch_reference_ratios(self, surah_number):
        """
        Fetches normalized [0.0..1.0] studio Murattal timing proportions for any Surah so non-segmented
        reciters (Ahmad Al-Ajmy, Maher, Warsh reciters, etc.) turn Mushaf pages right on time!
        """
        if surah_number in self._ref_ratios_cache:
            return self._ref_ratios_cache[surah_number]
        url = f"https://api.quran.com/api/v4/chapter_recitations/7/{surah_number}?segments=true"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
            with urllib.request.urlopen(req, timeout=6) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
                raw_ts = payload.get("audio_file", {}).get("timestamps", [])
                if not raw_ts:
                    return []
                total_ms = float(raw_ts[-1].get("timestamp_to", 0))
                if total_ms <= 0:
                    return []
                ratios = []
                for ts in raw_ts:
                    parts = str(ts.get("verse_key", "0:0")).split(":")
                    if len(parts) != 2:
                        continue
                    ratios.append((
                        int(parts[1]),
                        float(ts.get("timestamp_from", 0)) / total_ms,
                        float(ts.get("timestamp_to", 0)) / total_ms,
                    ))
                self._ref_ratios_cache[surah_number] = ratios
                return ratios
        except Exception:
            return []

    def fetch_surah_and_tafsir(self, surah_number, tafsir_edition="ar.muyassar", offline_mgr=None):
        mem = self.get_cached_surah_mem(surah_number, tafsir_edition)
        if mem is not None:
            return mem

        if offline_mgr:
            cached = offline_mgr.load_surah_json(surah_number, tafsir_edition)
            if cached:
                self._put_surah_mem(surah_number, tafsir_edition, cached["ayahs"], cached["tafsirs"])
                return cached["ayahs"], cached["tafsirs"]

        url = f"https://api.alquran.cloud/v1/surah/{surah_number}/editions/quran-uthmani,{tafsir_edition}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
            with urllib.request.urlopen(req, timeout=7) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
                q_ayahs = [{"num": a["numberInSurah"], "text": a["text"], "page": a.get("page", 1)} for a in payload["data"][0]["ayahs"]]
                t_ayahs = [{"num": a["numberInSurah"], "text": a["text"]} for a in payload["data"][1]["ayahs"]]
                self._put_surah_mem(surah_number, tafsir_edition, q_ayahs, t_ayahs)
                if offline_mgr:
                    offline_mgr.save_surah_json(surah_number, tafsir_edition, q_ayahs, t_ayahs)
                return q_ayahs, t_ayahs
        except Exception:
            fallback_page = SURAHS_LIST[max(0, min(113, int(surah_number) - 1))].get("page", 1)
            return [{"num": 1, "text": "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", "page": fallback_page}], [{"num": 1, "text": "تحقق من اتصال الإنترنت أو شغّل السور المحفوظة محلياً."}]

    def search_verses(self, keyword):
        encoded = urllib.parse.quote(keyword)
        url = f"https://api.alquran.cloud/v1/search/{encoded}/all/ar"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": f"QuranMizouh-Enigma2/{PLUGIN_VERSION}"})
            with urllib.request.urlopen(req, timeout=8) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
                matches = payload.get("data", {}).get("matches", [])
                return [
                    {
                        "surah": m["surah"]["number"],
                        "surah_name": m["surah"]["name"],
                        "ayah": m["numberInSurah"],
                        "text": m["text"],
                    }
                    for m in matches[:40]
                ]
        except Exception:
            return []
