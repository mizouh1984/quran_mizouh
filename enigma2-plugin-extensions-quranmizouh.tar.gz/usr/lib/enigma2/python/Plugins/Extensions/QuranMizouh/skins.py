# -*- coding: utf-8 -*-
"""
4 distinct handcrafted FullHD (1920x1080) Enigma2 Skins for قارئ القرآن - mizouh المتميز
Switchable live from the MENU screen without restarting Enigma2!
"""

SKIN_CHOICES = [
    ("emerald_gold", "الزمردي الذهبي (الأصلي)"),
    ("royal_blue", "الأزرق الملكي الليلي"),
    ("warm_walnut", "الكلاسيكي الدافئ (خشبي ذهبي)"),
    ("oled_black", "الأسود الفاحم OLED (تباين عالٍ)"),
]

SKIN_PALETTES = {
    "emerald_gold": {
        "bg": "#090E0D",
        "bar": "#101917",
        "panel": "#0D1513",
        "sidebar": "#111A18",
        "card": "#121D1A",
        "accent": "#C9A24D",
        "title": "#E5C878",
        "sub": "#A8BDB6",
        "text": "#EAECEB",
        "ayah": "#FFF3C8",
        "tafsir": "#C6D4CF",
        "divider": "#243531",
        "mushaf_frame": "#F5EFE1",
    },
    "royal_blue": {
        "bg": "#060D1A",
        "bar": "#0C1930",
        "panel": "#091428",
        "sidebar": "#0D1B34",
        "card": "#122444",
        "accent": "#38BDF8",
        "title": "#F5D061",
        "sub": "#9CC2E6",
        "text": "#F1F5F9",
        "ayah": "#FEF08A",
        "tafsir": "#CBD5E1",
        "divider": "#1E3A5F",
        "mushaf_frame": "#F4EFE4",
    },
    "warm_walnut": {
        "bg": "#15100A",
        "bar": "#221910",
        "panel": "#1C150E",
        "sidebar": "#241B12",
        "card": "#2C2116",
        "accent": "#DFB356",
        "title": "#F6DC96",
        "sub": "#C8B69A",
        "text": "#F7F1E5",
        "ayah": "#FFF4D1",
        "tafsir": "#DECDB3",
        "divider": "#403121",
        "mushaf_frame": "#F7F0DF",
    },
    "oled_black": {
        "bg": "#000000",
        "bar": "#0B0B0B",
        "panel": "#060606",
        "sidebar": "#0A0A0A",
        "card": "#121212",
        "accent": "#FACC15",
        "title": "#FDE047",
        "sub": "#D4D4D4",
        "text": "#FFFFFF",
        "ayah": "#FEF9C3",
        "tafsir": "#E5E5E5",
        "divider": "#262626",
        "mushaf_frame": "#FAF6EC",
    },
}


def get_palette(theme_key):
    return SKIN_PALETTES.get(theme_key, SKIN_PALETTES["emerald_gold"])


def build_main_skin(theme_key="emerald_gold"):
    p = get_palette(theme_key)
    return f"""
    <screen name="QuranMizouhMainScreen" position="0,0" size="1920,1080" title="قارئ القرآن - mizouh المتميز" flags="wfNoBorder" backgroundColor="{p['bg']}">
        <!-- Header Bar -->
        <eLabel position="0,0" size="1920,88" backgroundColor="{p['bar']}" zPosition="-1" />
        <eLabel position="0,88" size="1920,3" backgroundColor="{p['accent']}" zPosition="0" />
        <widget name="header_title" position="64,20" size="860,48" font="Regular;34" foregroundColor="{p['title']}" backgroundColor="{p['bar']}" halign="right" transparent="1" />
        <widget name="riwaya_label" position="940,24" size="916,42" font="Regular;25" foregroundColor="{p['sub']}" backgroundColor="{p['bar']}" halign="left" transparent="1" />

        <!-- Right Sidebar: 31+ Reciters & All 114 Surahs -->
        <eLabel position="1352,106" size="504,840" backgroundColor="{p['sidebar']}" zPosition="-1" />
        <widget name="reciter_title" position="1372,118" size="464,36" font="Regular;24" foregroundColor="{p['accent']}" backgroundColor="{p['sidebar']}" halign="right" transparent="1" />
        <widget name="reciter_list" position="1372,160" size="464,260" itemHeight="40" font="Regular;22" foregroundColor="{p['text']}" backgroundColor="{p['sidebar']}" scrollbarMode="showOnDemand" />
        <eLabel position="1372,430" size="464,2" backgroundColor="{p['divider']}" />
        <widget name="surah_title" position="1372,442" size="464,36" font="Regular;24" foregroundColor="{p['accent']}" backgroundColor="{p['sidebar']}" halign="right" transparent="1" />
        <widget name="surah_list" position="1372,484" size="464,448" itemHeight="40" font="Regular;22" foregroundColor="{p['text']}" backgroundColor="{p['sidebar']}" scrollbarMode="showOnDemand" />

        <!-- Center Pure Real Printed Mushaf Page (576x824, ZERO overlay bars or boxes) -->
        <eLabel position="708,106" size="600,840" backgroundColor="{p['mushaf_frame']}" zPosition="-1" />
        <widget name="mushaf_page" position="720,114" size="576,824" alphatest="blend" zPosition="1" />

        <!-- Interactive Text Mushaf Fallback -->
        <widget name="mushaf_text" position="714,122" size="588,808" font="Regular;30" foregroundColor="{p['text']}" backgroundColor="{p['panel']}" halign="right" zPosition="4" />

        <!-- Audio-Only Sanctuary View -->
        <widget name="audio_only_status" position="80,260" size="1220,300" font="Regular;38" foregroundColor="{p['title']}" backgroundColor="{p['panel']}" halign="center" valign="center" transparent="1" zPosition="5" />

        <!-- Left Pane: Surah Header + Ayah Text + Companion Tafsir -->
        <eLabel position="64,106" size="618,840" backgroundColor="{p['panel']}" zPosition="-1" />
        <widget name="surah_banner" position="84,124" size="578,48" font="Regular;28" foregroundColor="{p['title']}" backgroundColor="{p['panel']}" halign="center" transparent="1" />
        <widget name="active_ayah_label" position="84,186" size="578,225" font="Regular;26" foregroundColor="{p['ayah']}" backgroundColor="{p['card']}" halign="right" valign="center" />
        <eLabel position="84,424" size="578,2" backgroundColor="{p['accent']}" />
        <widget name="tafsir_text" position="84,440" size="578,490" font="Regular;23" foregroundColor="{p['tafsir']}" backgroundColor="{p['panel']}" halign="right" transparent="1" />

        <!-- Bottom Remote Control Color Key Bar -->
        <eLabel position="0,964" size="1920,116" backgroundColor="{p['bar']}" zPosition="-1" />
        <eLabel position="0,962" size="1920,2" backgroundColor="{p['divider']}" />

        <eLabel position="1828,996" size="22,22" backgroundColor="#DC2626" />
        <widget name="key_red" position="1560,988" size="256,38" font="Regular;22" foregroundColor="{p['text']}" halign="right" transparent="1" />

        <eLabel position="1520,996" size="22,22" backgroundColor="#16A34A" />
        <widget name="key_green" position="1226,988" size="282,38" font="Regular;22" foregroundColor="{p['text']}" halign="right" transparent="1" />

        <eLabel position="1186,996" size="22,22" backgroundColor="#EAB308" />
        <widget name="key_yellow" position="880,988" size="294,38" font="Regular;22" foregroundColor="{p['text']}" halign="right" transparent="1" />

        <eLabel position="840,996" size="22,22" backgroundColor="#2563EB" />
        <widget name="key_blue" position="560,988" size="268,38" font="Regular;22" foregroundColor="{p['text']}" halign="right" transparent="1" />

        <widget name="status_bar" position="64,988" size="476,38" font="Regular;21" foregroundColor="{p['title']}" halign="left" transparent="1" />
    </screen>
    """


def build_menu_skin(theme_key="emerald_gold"):
    p = get_palette(theme_key)
    return f"""
    <screen name="QuranMizouhMenuScreen" position="center,center" size="1340,840" title="قائمة الإعدادات والسكينات والتحديث" flags="wfNoBorder" backgroundColor="{p['bg']}">
        <eLabel position="0,0" size="1340,92" backgroundColor="{p['bar']}" zPosition="-1" />
        <eLabel position="0,92" size="1340,3" backgroundColor="{p['accent']}" zPosition="0" />
        <widget name="menu_title" position="40,18" size="1260,42" font="Regular;32" foregroundColor="{p['title']}" backgroundColor="{p['bar']}" halign="center" transparent="1" />
        <widget name="repo_info" position="40,58" size="1260,30" font="Regular;20" foregroundColor="{p['sub']}" backgroundColor="{p['bar']}" halign="center" transparent="1" />

        <widget name="config" position="45,116" size="1250,560" itemHeight="50" font="Regular;25" foregroundColor="{p['text']}" backgroundColor="{p['panel']}" scrollbarMode="showOnDemand" />

        <eLabel position="45,690" size="1250,2" backgroundColor="{p['divider']}" />
        <widget name="update_status" position="45,704" size="1250,38" font="Regular;22" foregroundColor="{p['ayah']}" halign="center" transparent="1" />

        <!-- Menu Bottom Color Actions -->
        <eLabel position="0,754" size="1340,86" backgroundColor="{p['bar']}" zPosition="-1" />

        <eLabel position="1268,784" size="20,20" backgroundColor="#DC2626" />
        <widget name="btn_red" position="1060,776" size="198,38" font="Regular;22" foregroundColor="{p['text']}" halign="right" transparent="1" />

        <eLabel position="1018,784" size="20,20" backgroundColor="#16A34A" />
        <widget name="btn_green" position="730,776" size="278,38" font="Regular;22" foregroundColor="{p['text']}" halign="right" transparent="1" />

        <eLabel position="688,784" size="20,20" backgroundColor="#EAB308" />
        <widget name="btn_yellow" position="390,776" size="288,38" font="Regular;22" foregroundColor="{p['text']}" halign="right" transparent="1" />

        <eLabel position="348,784" size="20,20" backgroundColor="#2563EB" />
        <widget name="btn_blue" position="40,776" size="298,38" font="Regular;22" foregroundColor="{p['text']}" halign="right" transparent="1" />
    </screen>
    """
